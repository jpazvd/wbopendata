{smcl}
{right:(as of 04jan2026)}

{marker indicators}{...}
{p 40 20 2}(Go up to {it:{help wbopendata##sections:Sections Menu}}){p_end}
{title:Topics}

{marker toc}
{p 40 20 2}(Go up to {it:{help wbopendata##topicid:Topics}}){p_end}
{synoptset 25 tabbed}{...}
{synopthdr:Topics Code}
{synoptline}
{synopt:{opt 01}}  {help wbopendata_topicid_indicators01##topicid_01:Agriculture and Rural Development}{p_end}
{synopt:{opt 02}}  {help wbopendata_topicid_indicators02##topicid_02:Aid Effectiveness}{p_end}
{synopt:{opt 03}}  {help wbopendata_topicid_indicators03##topicid_03:Economy and Growth}{p_end}
{synopt:{opt 04}}  {help wbopendata_topicid_indicators04##topicid_04:Education}{p_end}
{synopt:{opt 05}}  {help wbopendata_topicid_indicators05##topicid_05:Energy and Mining}{p_end}
{synopt:{opt 06}}  {help wbopendata_topicid_indicators06##topicid_06:Environment}{p_end}
{synopt:{opt 07}}  {help wbopendata_topicid_indicators07##topicid_07:Financial Sector}{p_end}
{synopt:{opt 08}}  {help wbopendata_topicid_indicators08##topicid_08:Health}{p_end}
{synopt:{opt 09}}  {help wbopendata_topicid_indicators09##topicid_09:Infrastructure}{p_end}
{synopt:{opt 10}}  {help wbopendata_topicid_indicators10##topicid_10:Social Protection and Labor}{p_end}
{synopt:{opt 11}}  {help wbopendata_topicid_indicators11##topicid_11:Poverty}{p_end}
{synopt:{opt 12}}  {help wbopendata_topicid_indicators12##topicid_12:Private Sector}{p_end}
{synopt:{opt 13}}  {help wbopendata_topicid_indicators13##topicid_13:Public Sector}{p_end}
{synopt:{opt 14}}  {help wbopendata_topicid_indicators14##topicid_14:Science and Technology}{p_end}
{synopt:{opt 15}}  {help wbopendata_topicid_indicators15##topicid_15:Social Development}{p_end}
{synopt:{opt 16}}  {help wbopendata_topicid_indicators16##topicid_16:Urban Development}{p_end}
{synopt:{opt 17}}  {help wbopendata_topicid_indicators17##topicid_17:Gender}{p_end}
{synopt:{opt 18}}  {help wbopendata_topicid_indicators18##topicid_18:Millenium development goals}{p_end}
{synopt:{opt 19}}  {help wbopendata_topicid_indicators19##topicid_19:Climate Change}{p_end}
{synopt:{opt 20}}  {help wbopendata_topicid_indicators20##topicid_20:External Debt}{p_end}
{synopt:{opt 21}}  {help wbopendata_topicid_indicators21##topicid_21:Trade}{p_end}
{synopt:{opt topicID}}  {help wbopendata_topicid_indicatorstopicID##topicid_topicID:}{p_end}


{marker topicid_10}
{p 40 20 2}(Go up to {it:{help wbopendata##topicid:Topics}} or {it:{help wbopendata_topicid_indicators10##:TOC}}){p_end}

{synoptset 25 tabbed}{...}
{syntab:{title:{bf:10 Social Protection and Labor}}}
{synoptline}
{marker topicid_4.0.nini.15a18}
{synopt:{bf:{help wbopendata_topicid##4.0.nini.15a18:4.0.nini.15a18} - Youth: Neither in School Nor Working  (15-18)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-18 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.nini.15a24}
{synopt:{bf:{help wbopendata_topicid##4.0.nini.15a24:4.0.nini.15a24} - Youth: Neither in School Nor Working  (15-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-24 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.nini.19a24}
{synopt:{bf:{help wbopendata_topicid##4.0.nini.19a24:4.0.nini.19a24} - Youth: Neither in School Nor Working  (19-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 19-24 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.stud.15a18}
{synopt:{bf:{help wbopendata_topicid##4.0.stud.15a18:4.0.stud.15a18} - Youth: In School (15-18)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-18 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.stud.15a24}
{synopt:{bf:{help wbopendata_topicid##4.0.stud.15a24:4.0.stud.15a24} - Youth: In School (15-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-24 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.stud.19a24}
{synopt:{bf:{help wbopendata_topicid##4.0.stud.19a24:4.0.stud.19a24} - Youth: In School (19-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 19-24 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.studwork.15a18}
{synopt:{bf:{help wbopendata_topicid##4.0.studwork.15a18:4.0.studwork.15a18} - Youth: In School and Employed (15-18)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-18 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.studwork.15a24}
{synopt:{bf:{help wbopendata_topicid##4.0.studwork.15a24:4.0.studwork.15a24} - Youth: In School and Employed (15-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-24 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.studwork.19a24}
{synopt:{bf:{help wbopendata_topicid##4.0.studwork.19a24:4.0.studwork.19a24} - Youth: In School and Employed (19-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 19-24 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.work.15a18}
{synopt:{bf:{help wbopendata_topicid##4.0.work.15a18:4.0.work.15a18} - Youth: Employed (15-18)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-18 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.work.15a24}
{synopt:{bf:{help wbopendata_topicid##4.0.work.15a24:4.0.work.15a24} - Youth: Employed (15-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 15-24 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.0.work.19a24}
{synopt:{bf:{help wbopendata_topicid##4.0.work.19a24:4.0.work.19a24} - Youth: Employed (19-24)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population ages 19-24 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.nini.15a18}
{synopt:{bf:{help wbopendata_topicid##4.1.nini.15a18:4.1.nini.15a18} - Youth: Neither in School Nor Working  (15-18), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-18 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.nini.15a24}
{synopt:{bf:{help wbopendata_topicid##4.1.nini.15a24:4.1.nini.15a24} - Youth: Neither in School Nor Working  (15-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-24 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.nini.19a24}
{synopt:{bf:{help wbopendata_topicid##4.1.nini.19a24:4.1.nini.19a24} - Youth: Neither in School Nor Working  (19-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 19-24 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.stud.15a18}
{synopt:{bf:{help wbopendata_topicid##4.1.stud.15a18:4.1.stud.15a18} - Youth: In School (15-18), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-18 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.stud.15a24}
{synopt:{bf:{help wbopendata_topicid##4.1.stud.15a24:4.1.stud.15a24} - Youth: In School (15-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-24 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.stud.19a24}
{synopt:{bf:{help wbopendata_topicid##4.1.stud.19a24:4.1.stud.19a24} - Youth: In School (19-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 19-24 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.studwork.15a18}
{synopt:{bf:{help wbopendata_topicid##4.1.studwork.15a18:4.1.studwork.15a18} - Youth: In School and Employed (15-18), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-18 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.studwork.15a24}
{synopt:{bf:{help wbopendata_topicid##4.1.studwork.15a24:4.1.studwork.15a24} - Youth: In School and Employed (15-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-24 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.studwork.19a24}
{synopt:{bf:{help wbopendata_topicid##4.1.studwork.19a24:4.1.studwork.19a24} - Youth: In School and Employed (19-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 19-24 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.work.15a18}
{synopt:{bf:{help wbopendata_topicid##4.1.work.15a18:4.1.work.15a18} - Youth: Employed (15-18), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-18 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.work.15a24}
{synopt:{bf:{help wbopendata_topicid##4.1.work.15a24:4.1.work.15a24} - Youth: Employed (15-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 15-24 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.1.work.19a24}
{synopt:{bf:{help wbopendata_topicid##4.1.work.19a24:4.1.work.19a24} - Youth: Employed (19-24), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population ages 19-24 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.nini.15a18}
{synopt:{bf:{help wbopendata_topicid##4.2.nini.15a18:4.2.nini.15a18} - Youth: Neither in School Nor Working  (15-18), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-18 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.nini.15a24}
{synopt:{bf:{help wbopendata_topicid##4.2.nini.15a24:4.2.nini.15a24} - Youth: Neither in School Nor Working  (15-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-24 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.nini.19a24}
{synopt:{bf:{help wbopendata_topicid##4.2.nini.19a24:4.2.nini.19a24} - Youth: Neither in School Nor Working  (19-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 19-24 that is neither employed nor in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.stud.15a18}
{synopt:{bf:{help wbopendata_topicid##4.2.stud.15a18:4.2.stud.15a18} - Youth: In School (15-18), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-18 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.stud.15a24}
{synopt:{bf:{help wbopendata_topicid##4.2.stud.15a24:4.2.stud.15a24} - Youth: In School (15-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-24 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.stud.19a24}
{synopt:{bf:{help wbopendata_topicid##4.2.stud.19a24:4.2.stud.19a24} - Youth: In School (19-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 19-24 that is in school and not employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.studwork.15a18}
{synopt:{bf:{help wbopendata_topicid##4.2.studwork.15a18:4.2.studwork.15a18} - Youth: In School and Employed (15-18), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-18 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.studwork.15a24}
{synopt:{bf:{help wbopendata_topicid##4.2.studwork.15a24:4.2.studwork.15a24} - Youth: In School and Employed (15-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-24 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.studwork.19a24}
{synopt:{bf:{help wbopendata_topicid##4.2.studwork.19a24:4.2.studwork.19a24} - Youth: In School and Employed (19-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 19-24 that is in school and employed.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.work.15a18}
{synopt:{bf:{help wbopendata_topicid##4.2.work.15a18:4.2.work.15a18} - Youth: Employed (15-18), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-18 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.work.15a24}
{synopt:{bf:{help wbopendata_topicid##4.2.work.15a24:4.2.work.15a24} - Youth: Employed (15-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 15-24 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_4.2.work.19a24}
{synopt:{bf:{help wbopendata_topicid##4.2.work.19a24:4.2.work.19a24} - Youth: Employed (19-24), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population ages 19-24 that is employed and not in school.{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank), based on Out of School and Out of Work: A Diagnostic of Ninis in Latin America by De Hoyos, Popova, and Rogers (2014, World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Employee.All}
{synopt:{bf:{help wbopendata_topicid##9.0.Employee.All:9.0.Employee.All} - Employees (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Employee.B40}
{synopt:{bf:{help wbopendata_topicid##9.0.Employee.B40:9.0.Employee.B40} - Employees-Bottom 40 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the bottom 40 percent that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Employee.T60}
{synopt:{bf:{help wbopendata_topicid##9.0.Employee.T60:9.0.Employee.T60} - Employees-Top 60 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the top 60 percent that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Employer.All}
{synopt:{bf:{help wbopendata_topicid##9.0.Employer.All:9.0.Employer.All} - Employers (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Employer.B40}
{synopt:{bf:{help wbopendata_topicid##9.0.Employer.B40:9.0.Employer.B40} - Employers-Bottom 40 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the bottom 40 percent that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Employer.T60}
{synopt:{bf:{help wbopendata_topicid##9.0.Employer.T60:9.0.Employer.T60} - Employers-Top 60 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the top 60 percent that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Labor.All}
{synopt:{bf:{help wbopendata_topicid##9.0.Labor.All:9.0.Labor.All} - Labor Force Participation Rate (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the population (ages 18-65) that is in the labor force{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.SelfEmp.All}
{synopt:{bf:{help wbopendata_topicid##9.0.SelfEmp.All:9.0.SelfEmp.All} - Self-Employed (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) that is self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.SelfEmp.B40}
{synopt:{bf:{help wbopendata_topicid##9.0.SelfEmp.B40:9.0.SelfEmp.B40} - Self-Employed-Bottom 40 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the bottom 40 percent that is self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.SelfEmp.T60}
{synopt:{bf:{help wbopendata_topicid##9.0.SelfEmp.T60:9.0.SelfEmp.T60} - Self-Employed-Top 60 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the top 60 percent that is a self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Unemp.All}
{synopt:{bf:{help wbopendata_topicid##9.0.Unemp.All:9.0.Unemp.All} - Unemployed (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Unemp.B40}
{synopt:{bf:{help wbopendata_topicid##9.0.Unemp.B40:9.0.Unemp.B40} - Unemployed-Bottom 40 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the bottom 40 percent that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Unemp.T60}
{synopt:{bf:{help wbopendata_topicid##9.0.Unemp.T60:9.0.Unemp.T60} - Unemployed-Top 60 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the top 60 percent that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Unpaid.All}
{synopt:{bf:{help wbopendata_topicid##9.0.Unpaid.All:9.0.Unpaid.All} - Unpaid Workers (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Unpaid.B40}
{synopt:{bf:{help wbopendata_topicid##9.0.Unpaid.B40:9.0.Unpaid.B40} - Unpaid Workers-Bottom 40 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the bottom 40 percent that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.0.Unpaid.T60}
{synopt:{bf:{help wbopendata_topicid##9.0.Unpaid.T60:9.0.Unpaid.T60} - Unpaid Workers-Top 60 Percent (%)}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the labor force (ages 18-65) in the top 60 percent that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Employee.All}
{synopt:{bf:{help wbopendata_topicid##9.1.Employee.All:9.1.Employee.All} - Employees (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Employee.B40}
{synopt:{bf:{help wbopendata_topicid##9.1.Employee.B40:9.1.Employee.B40} - Employees-Bottom 40 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the bottom 40 percent that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Employee.T60}
{synopt:{bf:{help wbopendata_topicid##9.1.Employee.T60:9.1.Employee.T60} - Employees-Top 60 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the top 60 percent that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Employer.All}
{synopt:{bf:{help wbopendata_topicid##9.1.Employer.All:9.1.Employer.All} - Employers (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Employer.B40}
{synopt:{bf:{help wbopendata_topicid##9.1.Employer.B40:9.1.Employer.B40} - Employers-Bottom 40 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the bottom 40 percent that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Employer.T60}
{synopt:{bf:{help wbopendata_topicid##9.1.Employer.T60:9.1.Employer.T60} - Employers-Top 60 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the top 60 percent that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Labor.All}
{synopt:{bf:{help wbopendata_topicid##9.1.Labor.All:9.1.Labor.All} - Labor Force Participation Rate (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male population (ages 18-65) that is in the labor force{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.SelfEmp.All}
{synopt:{bf:{help wbopendata_topicid##9.1.SelfEmp.All:9.1.SelfEmp.All} - Self-Employed (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) that is self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.SelfEmp.B40}
{synopt:{bf:{help wbopendata_topicid##9.1.SelfEmp.B40:9.1.SelfEmp.B40} - Self-Employed-Bottom 40 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the bottom 40 percent that is self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.SelfEmp.T60}
{synopt:{bf:{help wbopendata_topicid##9.1.SelfEmp.T60:9.1.SelfEmp.T60} - Self-Employed-Top 60 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the top 60 percent that is a self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Unemp.All}
{synopt:{bf:{help wbopendata_topicid##9.1.Unemp.All:9.1.Unemp.All} - Unemployed (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Unemp.B40}
{synopt:{bf:{help wbopendata_topicid##9.1.Unemp.B40:9.1.Unemp.B40} - Unemployed-Bottom 40 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the bottom 40 percent that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Unemp.T60}
{synopt:{bf:{help wbopendata_topicid##9.1.Unemp.T60:9.1.Unemp.T60} - Unemployed-Top 60 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the top 60 percent that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Unpaid.All}
{synopt:{bf:{help wbopendata_topicid##9.1.Unpaid.All:9.1.Unpaid.All} - Unpaid Workers (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Unpaid.B40}
{synopt:{bf:{help wbopendata_topicid##9.1.Unpaid.B40:9.1.Unpaid.B40} - Unpaid Workers-Bottom 40 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the bottom 40 percent that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.1.Unpaid.T60}
{synopt:{bf:{help wbopendata_topicid##9.1.Unpaid.T60:9.1.Unpaid.T60} - Unpaid Workers-Top 60 Percent (%), Male}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the male labor force (ages 18-65) in the top 60 percent that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Employee.All}
{synopt:{bf:{help wbopendata_topicid##9.2.Employee.All:9.2.Employee.All} - Employees (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Employee.B40}
{synopt:{bf:{help wbopendata_topicid##9.2.Employee.B40:9.2.Employee.B40} - Employees-Bottom 40 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the bottom 40 percent that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Employee.T60}
{synopt:{bf:{help wbopendata_topicid##9.2.Employee.T60:9.2.Employee.T60} - Employees-Top 60 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the top 60 percent that is a wage or salary worker{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Employer.All}
{synopt:{bf:{help wbopendata_topicid##9.2.Employer.All:9.2.Employer.All} - Employers (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Employer.B40}
{synopt:{bf:{help wbopendata_topicid##9.2.Employer.B40:9.2.Employer.B40} - Employers-Bottom 40 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the bottom 40 percent that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Employer.T60}
{synopt:{bf:{help wbopendata_topicid##9.2.Employer.T60:9.2.Employer.T60} - Employers-Top 60 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the top 60 percent that is an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Labor.All}
{synopt:{bf:{help wbopendata_topicid##9.2.Labor.All:9.2.Labor.All} - Labor Force Participation Rate (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female population (ages 18-65) that is in the labor force{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.SelfEmp.All}
{synopt:{bf:{help wbopendata_topicid##9.2.SelfEmp.All:9.2.SelfEmp.All} - Self-Employed (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) that is self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.SelfEmp.B40}
{synopt:{bf:{help wbopendata_topicid##9.2.SelfEmp.B40:9.2.SelfEmp.B40} - Self-Employed-Bottom 40 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the bottom 40 percent that is self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.SelfEmp.T60}
{synopt:{bf:{help wbopendata_topicid##9.2.SelfEmp.T60:9.2.SelfEmp.T60} - Self-Employed-Top 60 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the top 60 percent that is a self-employed and not an employer{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Unemp.All}
{synopt:{bf:{help wbopendata_topicid##9.2.Unemp.All:9.2.Unemp.All} - Unemployed (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Unemp.B40}
{synopt:{bf:{help wbopendata_topicid##9.2.Unemp.B40:9.2.Unemp.B40} - Unemployed-Bottom 40 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the bottom 40 percent that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Unemp.T60}
{synopt:{bf:{help wbopendata_topicid##9.2.Unemp.T60:9.2.Unemp.T60} - Unemployed-Top 60 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the top 60 percent that is unemployed{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Unpaid.All}
{synopt:{bf:{help wbopendata_topicid##9.2.Unpaid.All:9.2.Unpaid.All} - Unpaid Workers (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Unpaid.B40}
{synopt:{bf:{help wbopendata_topicid##9.2.Unpaid.B40:9.2.Unpaid.B40} - Unpaid Workers-Bottom 40 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the bottom 40 percent that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_9.2.Unpaid.T60}
{synopt:{bf:{help wbopendata_topicid##9.2.Unpaid.T60:9.2.Unpaid.T60} - Unpaid Workers-Top 60 Percent (%), Female}}

{synopt:{opt Source}}37 LAC Equity Lab{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Share of the female labor force (ages 18-65) in the top 60 percent that works without pay{p_end}

{synopt:{opt Source Organization}}LAC Equity Lab tabulations of SEDLAC (CEDLAS and the World Bank).{p_end}


{synoptline}
{marker topicid_per_allsp.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_ep_preT_tot:per_allsp.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_ep_tot:per_allsp.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_pop_rur:per_allsp.adq_pop_rur} - Adequacy of benefits (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_pop_tot:per_allsp.adq_pop_tot} - Adequacy of social protection and labor programs (% of total welfare of beneficiary households)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Adequacy of social protection and labor programs (SPL) is measured by the total transfer amount received by the population participating in social insurance, social safety net, and unemployment benefits and active labor market programs as a sh{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_allsp.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_pop_urb:per_allsp.adq_pop_urb} - Adequacy of benefits (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q1_preT_tot:per_allsp.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q1_rur:per_allsp.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q1_tot:per_allsp.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q1_urb:per_allsp.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q2_preT_tot:per_allsp.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q2_rur:per_allsp.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q2_tot:per_allsp.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q2_urb:per_allsp.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q3_preT_tot:per_allsp.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q3_rur:per_allsp.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q3_tot:per_allsp.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q3_urb:per_allsp.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q4_preT_tot:per_allsp.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q4_rur:per_allsp.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q4_tot:per_allsp.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q4_urb:per_allsp.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q5_preT_tot:per_allsp.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q5_rur:per_allsp.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q5_tot:per_allsp.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.adq_q5_urb:per_allsp.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_ep_preT_tot:per_allsp.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) -All Social Protection and Labor  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_ep_tot:per_allsp.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_pop_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_pop_preT_tot:per_allsp.avt_pop_preT_tot} - Average per capita transfer -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}87 Country Climate and Development Report (CCDR){p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_pop_rur:per_allsp.avt_pop_rur} - Average per capita transfer -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_pop_tot:per_allsp.avt_pop_tot} - Average per capita transfer -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_pop_urb:per_allsp.avt_pop_urb} - Average per capita transfer -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q1_preT_tot:per_allsp.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q1_rur:per_allsp.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q1_tot:per_allsp.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q1_urb:per_allsp.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q2_preT_tot:per_allsp.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q2_rur:per_allsp.avt_q2_rur} - Average per capita transfer held by 2nd quintile -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q2_tot:per_allsp.avt_q2_tot} - Average per capita transfer held by 2nd quintile -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q2_urb:per_allsp.avt_q2_urb} - Average per capita transfer held by 2nd quintile -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q3_preT_tot:per_allsp.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q3_rur:per_allsp.avt_q3_rur} - Average per capita transfer held by 3rd quintile -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q3_tot:per_allsp.avt_q3_tot} - Average per capita transfer held by 3rd quintile -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q3_urb:per_allsp.avt_q3_urb} - Average per capita transfer held by 3rd quintile -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q4_preT_tot:per_allsp.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q4_rur:per_allsp.avt_q4_rur} - Average per capita transfer held by 4th quintile -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q4_tot:per_allsp.avt_q4_tot} - Average per capita transfer held by 4th quintile -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q4_urb:per_allsp.avt_q4_urb} - Average per capita transfer held by 4th quintile -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q5_preT_tot:per_allsp.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q5_rur:per_allsp.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q5_tot:per_allsp.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.avt_q5_urb:per_allsp.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Protection and Labor programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_ep_preT_tot:per_allsp.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_ep_tot:per_allsp.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q1_preT_tot:per_allsp.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q1_rur:per_allsp.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q1_tot:per_allsp.ben_q1_tot} - Benefit incidence of social protection and labor programs to poorest quintile (% of total SPL benefits)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Benefit incidence of social protection and labor programs (SPL) to poorest quintile shows the percentage of total social protection and labor programs benefits received by the poorest 20% of the population. Social protection and labor programs{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q1_urb:per_allsp.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q2_preT_tot:per_allsp.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q2_rur:per_allsp.ben_q2_rur} - Benefits incidence in 2nd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q2_tot:per_allsp.ben_q2_tot} - Benefits incidence in 2nd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q2_urb:per_allsp.ben_q2_urb} - Benefits incidence in 2nd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q3_preT_tot:per_allsp.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q3_rur:per_allsp.ben_q3_rur} - Benefits incidence in 3rd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q3_tot:per_allsp.ben_q3_tot} - Benefits incidence in 3rd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q3_urb:per_allsp.ben_q3_urb} - Benefits incidence in 3rd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q4_preT_tot:per_allsp.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q4_rur:per_allsp.ben_q4_rur} - Benefits incidence in 4th quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q4_tot:per_allsp.ben_q4_tot} - Benefits incidence in 4th quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q4_urb:per_allsp.ben_q4_urb} - Benefits incidence in 4th quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q5_preT_tot:per_allsp.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q5_rur:per_allsp.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q5_tot:per_allsp.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.ben_q5_urb:per_allsp.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_ep_preT_tot:per_allsp.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_ep_tot:per_allsp.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q1_preT_tot:per_allsp.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q1_rur:per_allsp.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q1_tot:per_allsp.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q1_urb:per_allsp.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q2_preT_tot:per_allsp.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q2_rur:per_allsp.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q2_tot:per_allsp.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q2_urb:per_allsp.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q3_preT_tot:per_allsp.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q3_rur:per_allsp.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q3_tot:per_allsp.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q3_urb:per_allsp.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q4_preT_tot:per_allsp.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q4_rur:per_allsp.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q4_tot:per_allsp.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q4_urb:per_allsp.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q5_preT_tot:per_allsp.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q5_rur:per_allsp.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q5_tot:per_allsp.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.bry_q5_urb:per_allsp.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cba_ep_tot:per_allsp.cba_ep_tot} - Benefit-cost ratio - All Social Protection and Labor -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in SPL programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cba_q1_rur:per_allsp.cba_q1_rur} - Benefit-cost ratio - All Social Protection and Labor -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in SPL programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cba_q1_tot:per_allsp.cba_q1_tot} - Benefit-cost ratio - All Social Protection and Labor -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in SPL programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cba_q1_urb:per_allsp.cba_q1_urb} - Benefit-cost ratio - All Social Protection and Labor - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in SPL programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_ep_preT_tot:per_allsp.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_ep_tot:per_allsp.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_pop_rur:per_allsp.cov_pop_rur} - Coverage (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_pop_tot:per_allsp.cov_pop_tot} - Coverage of social protection and labor programs (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of social protection and labor programs (SPL) shows the percentage of population participating in social insurance, social safety net, and unemployment benefits and active labor market programs. Estimates include both direct and indir{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_allsp.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_pop_urb:per_allsp.cov_pop_urb} - Coverage (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q1_preT_tot:per_allsp.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q1_rur:per_allsp.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q1_tot:per_allsp.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q1_urb:per_allsp.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q2_preT_tot:per_allsp.cov_q2_preT_tot} - Coverage in 2nd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q2_rur:per_allsp.cov_q2_rur} - Coverage in 2nd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q2_tot:per_allsp.cov_q2_tot} - Coverage in 2nd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q2_urb:per_allsp.cov_q2_urb} - Coverage in 2nd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q3_preT_tot:per_allsp.cov_q3_preT_tot} - Coverage in 3rd quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q3_rur:per_allsp.cov_q3_rur} - Coverage in 3rd quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q3_tot:per_allsp.cov_q3_tot} - Coverage in 3rd quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q3_urb:per_allsp.cov_q3_urb} - Coverage in 3rd quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q4_preT_tot:per_allsp.cov_q4_preT_tot} - Coverage in 4th quintile (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q4_rur:per_allsp.cov_q4_rur} - Coverage in 4th quintile (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q4_tot:per_allsp.cov_q4_tot} - Coverage in 4th quintile (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q4_urb:per_allsp.cov_q4_urb} - Coverage in 4th quintile (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q5_preT_tot:per_allsp.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) -All Social Protection and Labor (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q5_rur:per_allsp.cov_q5_rur} - Coverage in 5th quintile (richest) (%) -All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q5_tot:per_allsp.cov_q5_tot} - Coverage in 5th quintile (richest) (%) -All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp.cov_q5_urb:per_allsp.cov_q5_urb} - Coverage in 5th quintile (richest) (%) -All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Protection and Labor programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp_gini_rur:per_allsp_gini_rur} - Gini inequality index reduction (%) - All Social Protection and Labor -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to SPL programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp_gini_tot:per_allsp_gini_tot} - Gini inequality index reduction (%) - All Social Protection and Labor}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to SPL programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp_gini_urb:per_allsp_gini_urb} - Gini inequality index reduction (%) - All Social Protection and Labor -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to SPL programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p0_ep_tot:per_allsp_p0_ep_tot} - Poverty Headcount reduction (%) - All Social Protection and Labor -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to SPL programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p0_rur:per_allsp_p0_rur} - Poverty Headcount reduction (%) - All Social Protection and Labor -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to SPL programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p0_tot:per_allsp_p0_tot} - Poverty Headcount reduction (%) - All Social Protection and Labor -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to SPL programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p0_urb:per_allsp_p0_urb} - Poverty Headcount reduction (%) - All Social Protection and Labor - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to SPL programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p1_ep_tot:per_allsp_p1_ep_tot} - Poverty Gap reduction (%) - All Social Protection and Labor -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to SPL programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p1_rur:per_allsp_p1_rur} - Poverty Gap reduction (%) - All Social Protection and Labor -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to SPL programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p1_tot:per_allsp_p1_tot} - Poverty Gap reduction (%) - All Social Protection and Labor -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to SPL programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_allsp_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_allsp_p1_urb:per_allsp_p1_urb} - Poverty Gap reduction (%) - All Social Protection and Labor - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to SPL programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_ep_preT_tot:per_lm_ac.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_ep_tot:per_lm_ac.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_pop_rur:per_lm_ac.adq_pop_rur} - Adequacy of benefits (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_pop_tot:per_lm_ac.adq_pop_tot} - Adequacy of benefits (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_pop_urb:per_lm_ac.adq_pop_urb} - Adequacy of benefits (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q1_preT_tot:per_lm_ac.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q1_rur:per_lm_ac.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q1_tot:per_lm_ac.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q1_urb:per_lm_ac.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q2_preT_tot:per_lm_ac.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q2_rur:per_lm_ac.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q2_tot:per_lm_ac.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q2_urb:per_lm_ac.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q3_preT_tot:per_lm_ac.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q3_rur:per_lm_ac.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q3_tot:per_lm_ac.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q3_urb:per_lm_ac.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q4_preT_tot:per_lm_ac.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q4_rur:per_lm_ac.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q4_tot:per_lm_ac.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q4_urb:per_lm_ac.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q5_preT_tot:per_lm_ac.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q5_rur:per_lm_ac.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q5_tot:per_lm_ac.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.adq_q5_urb:per_lm_ac.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_ep_preT_tot:per_lm_ac.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Active Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_ep_tot:per_lm_ac.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_pop_rur:per_lm_ac.avt_pop_rur} - Average per capita transfer - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_pop_tot:per_lm_ac.avt_pop_tot} - Average per capita transfer - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_pop_urb:per_lm_ac.avt_pop_urb} - Average per capita transfer - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q1_preT_tot:per_lm_ac.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q1_rur:per_lm_ac.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q1_tot:per_lm_ac.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q1_urb:per_lm_ac.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q2_preT_tot:per_lm_ac.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q2_rur:per_lm_ac.avt_q2_rur} - Average per capita transfer held by 2nd quintile - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q2_tot:per_lm_ac.avt_q2_tot} - Average per capita transfer held by 2nd quintile - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q2_urb:per_lm_ac.avt_q2_urb} - Average per capita transfer held by 2nd quintile - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q3_preT_tot:per_lm_ac.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q3_rur:per_lm_ac.avt_q3_rur} - Average per capita transfer held by 3rd quintile - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q3_tot:per_lm_ac.avt_q3_tot} - Average per capita transfer held by 3rd quintile - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q3_urb:per_lm_ac.avt_q3_urb} - Average per capita transfer held by 3rd quintile - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q4_preT_tot:per_lm_ac.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q4_rur:per_lm_ac.avt_q4_rur} - Average per capita transfer held by 4th quintile - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q4_tot:per_lm_ac.avt_q4_tot} - Average per capita transfer held by 4th quintile - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q4_urb:per_lm_ac.avt_q4_urb} - Average per capita transfer held by 4th quintile - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q5_preT_tot:per_lm_ac.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q5_rur:per_lm_ac.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q5_tot:per_lm_ac.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.avt_q5_urb:per_lm_ac.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Active Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_ep_preT_tot:per_lm_ac.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_ep_tot:per_lm_ac.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q1_preT_tot:per_lm_ac.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q1_rur:per_lm_ac.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q1_tot:per_lm_ac.ben_q1_tot} - Benefits incidence in 1st quintile (poorest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q1_urb:per_lm_ac.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q2_preT_tot:per_lm_ac.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q2_rur:per_lm_ac.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q2_tot:per_lm_ac.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q2_urb:per_lm_ac.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q3_preT_tot:per_lm_ac.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q3_rur:per_lm_ac.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q3_tot:per_lm_ac.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q3_urb:per_lm_ac.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q4_preT_tot:per_lm_ac.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q4_rur:per_lm_ac.ben_q4_rur} - Benefits incidence in 4th quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q4_tot:per_lm_ac.ben_q4_tot} - Benefits incidence in 4th quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q4_urb:per_lm_ac.ben_q4_urb} - Benefits incidence in 4th quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q5_preT_tot:per_lm_ac.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q5_rur:per_lm_ac.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q5_tot:per_lm_ac.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.ben_q5_urb:per_lm_ac.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_ep_preT_tot:per_lm_ac.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_ep_tot:per_lm_ac.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q1_preT_tot:per_lm_ac.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q1_rur:per_lm_ac.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q1_tot:per_lm_ac.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q1_urb:per_lm_ac.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q2_preT_tot:per_lm_ac.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q2_rur:per_lm_ac.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q2_tot:per_lm_ac.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q2_urb:per_lm_ac.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q3_preT_tot:per_lm_ac.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q3_rur:per_lm_ac.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q3_tot:per_lm_ac.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q3_urb:per_lm_ac.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q4_preT_tot:per_lm_ac.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q4_rur:per_lm_ac.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q4_tot:per_lm_ac.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q4_urb:per_lm_ac.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q5_preT_tot:per_lm_ac.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q5_rur:per_lm_ac.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q5_tot:per_lm_ac.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.bry_q5_urb:per_lm_ac.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cba_ep_tot:per_lm_ac.cba_ep_tot} - Benefit-cost ratio -  Active Labor Market  -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Active Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cba_q1_rur:per_lm_ac.cba_q1_rur} - Benefit-cost ratio -  Active Labor Market  -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Active Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cba_q1_tot:per_lm_ac.cba_q1_tot} - Benefit-cost ratio -  Active Labor Market  -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Active Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cba_q1_urb:per_lm_ac.cba_q1_urb} - Benefit-cost ratio -  Active Labor Market  - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Active Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_ep_preT_tot:per_lm_ac.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_ep_tot:per_lm_ac.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_pop_rur:per_lm_ac.cov_pop_rur} - Coverage (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_pop_tot:per_lm_ac.cov_pop_tot} - Coverage (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_pop_urb:per_lm_ac.cov_pop_urb} - Coverage (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q1_preT_tot:per_lm_ac.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q1_rur:per_lm_ac.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q1_tot:per_lm_ac.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q1_urb:per_lm_ac.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q2_preT_tot:per_lm_ac.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q2_rur:per_lm_ac.cov_q2_rur} - Coverage in 2nd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q2_tot:per_lm_ac.cov_q2_tot} - Coverage in 2nd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q2_urb:per_lm_ac.cov_q2_urb} - Coverage in 2nd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q3_preT_tot:per_lm_ac.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q3_rur:per_lm_ac.cov_q3_rur} - Coverage in 3rd quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q3_tot:per_lm_ac.cov_q3_tot} - Coverage in 3rd quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q3_urb:per_lm_ac.cov_q3_urb} - Coverage in 3rd quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q4_preT_tot:per_lm_ac.cov_q4_preT_tot} - Coverage in 4th quintile (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q4_rur:per_lm_ac.cov_q4_rur} - Coverage in 4th quintile (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q4_tot:per_lm_ac.cov_q4_tot} - Coverage in 4th quintile (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q4_urb:per_lm_ac.cov_q4_urb} - Coverage in 4th quintile (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q5_preT_tot:per_lm_ac.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - Active Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q5_rur:per_lm_ac.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q5_tot:per_lm_ac.cov_q5_tot} - Coverage in 5th quintile (richest) (%) - Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac.cov_q5_urb:per_lm_ac.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Active Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_gini_rur:per_lm_ac_gini_rur} - Gini inequality index reduction (%) -  Active Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Active Labor Market programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_gini_tot:per_lm_ac_gini_tot} - Gini inequality index reduction (%) -  Active Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Active Labor Market programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_gini_urb:per_lm_ac_gini_urb} - Gini inequality index reduction (%) -  Active Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Active Labor Market programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p0_ep_tot:per_lm_ac_p0_ep_tot} - Poverty Headcount reduction (%) -  Active Labor Market  -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Active Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p0_rur:per_lm_ac_p0_rur} - Poverty Headcount reduction (%) -  Active Labor Market  -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Active Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p0_tot:per_lm_ac_p0_tot} - Poverty Headcount reduction (%) -  Active Labor Market  -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Active Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p0_urb:per_lm_ac_p0_urb} - Poverty Headcount reduction (%) -  Active Labor Market  - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Active Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p1_ep_tot:per_lm_ac_p1_ep_tot} - Poverty Gap reduction (%) -  Active Labor Market  -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Active Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p1_rur:per_lm_ac_p1_rur} - Poverty Gap reduction (%) -  Active Labor Market  -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Active Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p1_tot:per_lm_ac_p1_tot} - Poverty Gap reduction (%) -  Active Labor Market  -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Active Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_ac_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_ac_p1_urb:per_lm_ac_p1_urb} - Poverty Gap reduction (%) -  Active Labor Market  - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Active Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_ep_preT_tot:per_lm_alllm.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - All Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_ep_tot:per_lm_alllm.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_pop_rur:per_lm_alllm.adq_pop_rur} - Adequacy of benefits (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_pop_tot:per_lm_alllm.adq_pop_tot} - Adequacy of unemployment benefits and ALMP (% of total welfare of beneficiary households)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Adequacy of unemployment benefits and active labor market programs (ALMP) is measured by the total transfer amount received by the population participating in unemployment benefits and active labor market programs as a share of their total wel{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_pop_urb:per_lm_alllm.adq_pop_urb} - Adequacy of benefits (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q1_preT_tot:per_lm_alllm.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q1_rur:per_lm_alllm.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q1_tot:per_lm_alllm.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q1_urb:per_lm_alllm.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q2_preT_tot:per_lm_alllm.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q2_rur:per_lm_alllm.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q2_tot:per_lm_alllm.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q2_urb:per_lm_alllm.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q3_preT_tot:per_lm_alllm.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q3_rur:per_lm_alllm.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q3_tot:per_lm_alllm.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q3_urb:per_lm_alllm.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q4_preT_tot:per_lm_alllm.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q4_rur:per_lm_alllm.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q4_tot:per_lm_alllm.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q4_urb:per_lm_alllm.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q5_preT_tot:per_lm_alllm.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q5_rur:per_lm_alllm.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q5_tot:per_lm_alllm.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.adq_q5_urb:per_lm_alllm.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_ep_preT_tot:per_lm_alllm.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - All Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_ep_tot:per_lm_alllm.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_pop_rur:per_lm_alllm.avt_pop_rur} - Average per capita transfer - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_pop_tot:per_lm_alllm.avt_pop_tot} - Average per capita transfer - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_pop_urb:per_lm_alllm.avt_pop_urb} - Average per capita transfer - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q1_preT_tot:per_lm_alllm.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q1_rur:per_lm_alllm.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q1_tot:per_lm_alllm.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q1_urb:per_lm_alllm.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q2_preT_tot:per_lm_alllm.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q2_rur:per_lm_alllm.avt_q2_rur} - Average per capita transfer held by 2nd quintile - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q2_tot:per_lm_alllm.avt_q2_tot} - Average per capita transfer held by 2nd quintile - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q2_urb:per_lm_alllm.avt_q2_urb} - Average per capita transfer held by 2nd quintile - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q3_preT_tot:per_lm_alllm.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q3_rur:per_lm_alllm.avt_q3_rur} - Average per capita transfer held by 3rd quintile - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q3_tot:per_lm_alllm.avt_q3_tot} - Average per capita transfer held by 3rd quintile - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q3_urb:per_lm_alllm.avt_q3_urb} - Average per capita transfer held by 3rd quintile - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q4_preT_tot:per_lm_alllm.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q4_rur:per_lm_alllm.avt_q4_rur} - Average per capita transfer held by 4th quintile - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q4_tot:per_lm_alllm.avt_q4_tot} - Average per capita transfer held by 4th quintile - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q4_urb:per_lm_alllm.avt_q4_urb} - Average per capita transfer held by 4th quintile - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q5_preT_tot:per_lm_alllm.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q5_rur:per_lm_alllm.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q5_tot:per_lm_alllm.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.avt_q5_urb:per_lm_alllm.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Labor Market programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_ep_preT_tot:per_lm_alllm.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - All Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_ep_tot:per_lm_alllm.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q1_preT_tot:per_lm_alllm.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q1_rur:per_lm_alllm.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q1_tot:per_lm_alllm.ben_q1_tot} - Benefit incidence of unemployment benefits and ALMP to poorest quintile (% of total U/ALMP benefits)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Benefit incidence of unemployment benefits and active labor market programs (ALMP) to poorest quintile shows the percentage of total unemployment and active labor market programs benefits received by the poorest 20% of the population. Unemploy{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q1_urb:per_lm_alllm.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q2_preT_tot:per_lm_alllm.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q2_rur:per_lm_alllm.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q2_tot:per_lm_alllm.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q2_urb:per_lm_alllm.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q3_preT_tot:per_lm_alllm.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q3_rur:per_lm_alllm.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q3_tot:per_lm_alllm.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q3_urb:per_lm_alllm.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q4_preT_tot:per_lm_alllm.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q4_rur:per_lm_alllm.ben_q4_rur} - Benefits incidence in 4th quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q4_tot:per_lm_alllm.ben_q4_tot} - Benefits incidence in 4th quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q4_urb:per_lm_alllm.ben_q4_urb} - Benefits incidence in 4th quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q5_preT_tot:per_lm_alllm.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q5_rur:per_lm_alllm.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q5_tot:per_lm_alllm.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.ben_q5_urb:per_lm_alllm.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_ep_preT_tot:per_lm_alllm.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - All Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_ep_tot:per_lm_alllm.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q1_preT_tot:per_lm_alllm.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q1_rur:per_lm_alllm.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q1_tot:per_lm_alllm.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q1_urb:per_lm_alllm.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q2_preT_tot:per_lm_alllm.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q2_rur:per_lm_alllm.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q2_tot:per_lm_alllm.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q2_urb:per_lm_alllm.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q3_preT_tot:per_lm_alllm.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q3_rur:per_lm_alllm.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q3_tot:per_lm_alllm.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q3_urb:per_lm_alllm.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q4_preT_tot:per_lm_alllm.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q4_rur:per_lm_alllm.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q4_tot:per_lm_alllm.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q4_urb:per_lm_alllm.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q5_preT_tot:per_lm_alllm.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q5_rur:per_lm_alllm.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q5_tot:per_lm_alllm.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.bry_q5_urb:per_lm_alllm.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cba_ep_tot:per_lm_alllm.cba_ep_tot} - Benefit-cost ratio -  All Labor Market  -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cba_q1_rur:per_lm_alllm.cba_q1_rur} - Benefit-cost ratio -  All Labor Market  -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cba_q1_tot:per_lm_alllm.cba_q1_tot} - Benefit-cost ratio -  All Labor Market  -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cba_q1_urb:per_lm_alllm.cba_q1_urb} - Benefit-cost ratio -  All Labor Market  - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Labor Market programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_ep_preT_tot:per_lm_alllm.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - All Labor Market  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_ep_tot:per_lm_alllm.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_pop_rur:per_lm_alllm.cov_pop_rur} - Coverage (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_pop_tot:per_lm_alllm.cov_pop_tot} - Coverage of unemployment benefits and ALMP (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of unemployment benefits and active labor market programs (ALMP) shows the percentage of population participating in unemployment compensation, severance pay, and early retirement due to labor market reasons, labor market services (in{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_pop_urb:per_lm_alllm.cov_pop_urb} - Coverage (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q1_preT_tot:per_lm_alllm.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q1_rur:per_lm_alllm.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q1_tot:per_lm_alllm.cov_q1_tot} - Coverage of unemployment benefits and ALMP in poorest quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of unemployment benefits and active labor market programs (ALMP) shows the percentage of population participating in unemployment compensation, severance pay, and early retirement due to labor market reasons, labor market services (in{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q1_urb:per_lm_alllm.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q2_preT_tot:per_lm_alllm.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q2_rur:per_lm_alllm.cov_q2_rur} - Coverage in 2nd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q2_tot:per_lm_alllm.cov_q2_tot} - Coverage of unemployment benefits and ALMP in 2nd quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of unemployment benefits and active labor market programs (ALMP) shows the percentage of population participating in unemployment compensation, severance pay, and early retirement due to labor market reasons, labor market services (in{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q2_urb:per_lm_alllm.cov_q2_urb} - Coverage in 2nd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q3_preT_tot:per_lm_alllm.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q3_rur:per_lm_alllm.cov_q3_rur} - Coverage in 3rd quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q3_tot:per_lm_alllm.cov_q3_tot} - Coverage of unemployment benefits and ALMP in 3rd quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of unemployment benefits and active labor market programs (ALMP) shows the percentage of population participating in unemployment compensation, severance pay, and early retirement due to labor market reasons, labor market services (in{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q3_urb:per_lm_alllm.cov_q3_urb} - Coverage in 3rd quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q4_preT_tot:per_lm_alllm.cov_q4_preT_tot} - Coverage in 4th quintile (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q4_rur:per_lm_alllm.cov_q4_rur} - Coverage in 4th quintile (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q4_tot:per_lm_alllm.cov_q4_tot} - Coverage of unemployment benefits and ALMP in 4th quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of unemployment benefits and active labor market programs (ALMP) shows the percentage of population participating in unemployment compensation, severance pay, and early retirement due to labor market reasons, labor market services (in{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q4_urb:per_lm_alllm.cov_q4_urb} - Coverage in 4th quintile (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q5_preT_tot:per_lm_alllm.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - All Labor Market (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q5_rur:per_lm_alllm.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q5_tot:per_lm_alllm.cov_q5_tot} - Coverage of unemployment benefits and ALMP in richest quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of unemployment benefits and active labor market programs (ALMP) shows the percentage of population participating in unemployment compensation, severance pay, and early retirement due to labor market reasons, labor market services (in{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_lm_alllm.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm.cov_q5_urb:per_lm_alllm.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_gini_rur:per_lm_alllm_gini_rur} - Gini inequality index reduction (%) -  All Labor Market -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Labor Market programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_gini_tot:per_lm_alllm_gini_tot} - Gini inequality index reduction (%) -  All Labor Market}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Labor Market programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_gini_urb:per_lm_alllm_gini_urb} - Gini inequality index reduction (%) -  All Labor Market -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Labor Market programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p0_ep_tot:per_lm_alllm_p0_ep_tot} - Poverty Headcount reduction (%) -  All Labor Market  -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p0_rur:per_lm_alllm_p0_rur} - Poverty Headcount reduction (%) -  All Labor Market  -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p0_tot:per_lm_alllm_p0_tot} - Poverty Headcount reduction (%) -  All Labor Market  -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p0_urb:per_lm_alllm_p0_urb} - Poverty Headcount reduction (%) -  All Labor Market  - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Labor Market programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p1_ep_tot:per_lm_alllm_p1_ep_tot} - Poverty Gap reduction (%) -  All Labor Market  -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p1_rur:per_lm_alllm_p1_rur} - Poverty Gap reduction (%) -  All Labor Market  -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p1_tot:per_lm_alllm_p1_tot} - Poverty Gap reduction (%) -  All Labor Market  -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lm_alllm_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lm_alllm_p1_urb:per_lm_alllm_p1_urb} - Poverty Gap reduction (%) -  All Labor Market  - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Labor Market programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_ep_preT_tot:per_lmonl.overlap_ep_preT_tot} - Population in extreme poor (&lt;$2.15 a day) only receiving Labor Market (%, preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_ep_tot:per_lmonl.overlap_ep_tot} - Population in extreme poor (&lt;$2.15 a day) only receiving Labor Market (%)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_pop_rur:per_lmonl.overlap_pop_rur} - Population only receiving Labor Market (%) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_pop_tot:per_lmonl.overlap_pop_tot} - Population only receiving Labor Market (%)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_pop_urb:per_lmonl.overlap_pop_urb} - Population only receiving Labor Market (%) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_q1_preT_tot:per_lmonl.overlap_q1_preT_tot} - Population in the 1st quintile (poorest) only receiving Labor Market (%, preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_q1_rur:per_lmonl.overlap_q1_rur} - Population in the 1st quintile (poorest) only receiving Labor Market (%) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_q1_tot:per_lmonl.overlap_q1_tot} - Population in the 1st quintile (poorest) only receiving Labor Market (%)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_lmonl.overlap_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_lmonl.overlap_q1_urb:per_lmonl.overlap_q1_urb} - Population in the 1st quintile (poorest) only receiving Labor Market (%) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population only receiving Labor Market programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_ep_preT_tot:per_nprog.overlap_ep_preT_tot} - Population in extreme poor (&lt;$2.15 a day) not receiving Social Protection (%, preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_ep_tot:per_nprog.overlap_ep_tot} - Population in extreme poor (&lt;$2.15 a day) not receiving Social Protection (%)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_pop_rur:per_nprog.overlap_pop_rur} - Population not receiving Social Protection (%) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_pop_tot:per_nprog.overlap_pop_tot} - Population not receiving Social Protection (%)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_pop_urb:per_nprog.overlap_pop_urb} - Population not receiving Social Protection (%) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_q1_preT_tot:per_nprog.overlap_q1_preT_tot} - Population in the 1st quintile (poorest) not receiving Social Protection (%, preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_q1_rur:per_nprog.overlap_q1_rur} - Population in the 1st quintile (poorest) not receiving Social Protection (%) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_q1_tot:per_nprog.overlap_q1_tot} - Population in the 1st quintile (poorest) not receiving Social Protection (%)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_nprog.overlap_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_nprog.overlap_q1_urb:per_nprog.overlap_q1_urb} - Population in the 1st quintile (poorest) not receiving Social Protection (%) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population not receiving Social Protection programs{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_ep_preT_tot:per_pr_dp.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_ep_tot:per_pr_dp.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_pop_rur:per_pr_dp.adq_pop_rur} - Adequacy of benefits (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_pop_tot:per_pr_dp.adq_pop_tot} - Adequacy of benefits (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_pop_urb:per_pr_dp.adq_pop_urb} - Adequacy of benefits (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q1_preT_tot:per_pr_dp.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q1_rur:per_pr_dp.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q1_tot:per_pr_dp.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q1_urb:per_pr_dp.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q2_preT_tot:per_pr_dp.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q2_rur:per_pr_dp.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q2_tot:per_pr_dp.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q2_urb:per_pr_dp.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q3_preT_tot:per_pr_dp.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q3_rur:per_pr_dp.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q3_tot:per_pr_dp.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q3_urb:per_pr_dp.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q4_preT_tot:per_pr_dp.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q4_rur:per_pr_dp.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q4_tot:per_pr_dp.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q4_urb:per_pr_dp.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q5_preT_tot:per_pr_dp.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q5_rur:per_pr_dp.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q5_tot:per_pr_dp.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.adq_q5_urb:per_pr_dp.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_ep_preT_tot:per_pr_dp.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_ep_tot:per_pr_dp.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_pop_rur:per_pr_dp.avt_pop_rur} - Average per capita transfer - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_pop_tot:per_pr_dp.avt_pop_tot} - Average per capita transfer - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_pop_urb:per_pr_dp.avt_pop_urb} - Average per capita transfer - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q1_preT_tot:per_pr_dp.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q1_rur:per_pr_dp.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q1_tot:per_pr_dp.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q1_urb:per_pr_dp.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q2_preT_tot:per_pr_dp.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q2_rur:per_pr_dp.avt_q2_rur} - Average per capita transfer held by 2nd quintile - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q2_tot:per_pr_dp.avt_q2_tot} - Average per capita transfer held by 2nd quintile - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q2_urb:per_pr_dp.avt_q2_urb} - Average per capita transfer held by 2nd quintile - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q3_preT_tot:per_pr_dp.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q3_rur:per_pr_dp.avt_q3_rur} - Average per capita transfer held by 3rd quintile - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q3_tot:per_pr_dp.avt_q3_tot} - Average per capita transfer held by 3rd quintile - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q3_urb:per_pr_dp.avt_q3_urb} - Average per capita transfer held by 3rd quintile - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q4_preT_tot:per_pr_dp.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q4_rur:per_pr_dp.avt_q4_rur} - Average per capita transfer held by 4th quintile - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q4_tot:per_pr_dp.avt_q4_tot} - Average per capita transfer held by 4th quintile - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q4_urb:per_pr_dp.avt_q4_urb} - Average per capita transfer held by 4th quintile - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q5_preT_tot:per_pr_dp.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q5_rur:per_pr_dp.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q5_tot:per_pr_dp.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.avt_q5_urb:per_pr_dp.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Domestic Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_ep_preT_tot:per_pr_dp.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_ep_tot:per_pr_dp.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q1_preT_tot:per_pr_dp.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q1_rur:per_pr_dp.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q1_tot:per_pr_dp.ben_q1_tot} - Benefits incidence in 1st quintile (poorest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q1_urb:per_pr_dp.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q2_preT_tot:per_pr_dp.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q2_rur:per_pr_dp.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q2_tot:per_pr_dp.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q2_urb:per_pr_dp.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q3_preT_tot:per_pr_dp.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q3_rur:per_pr_dp.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q3_tot:per_pr_dp.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q3_urb:per_pr_dp.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q4_preT_tot:per_pr_dp.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q4_rur:per_pr_dp.ben_q4_rur} - Benefits incidence in 4th quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q4_tot:per_pr_dp.ben_q4_tot} - Benefits incidence in 4th quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q4_urb:per_pr_dp.ben_q4_urb} - Benefits incidence in 4th quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q5_preT_tot:per_pr_dp.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q5_rur:per_pr_dp.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q5_tot:per_pr_dp.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.ben_q5_urb:per_pr_dp.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_ep_preT_tot:per_pr_dp.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_ep_tot:per_pr_dp.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q1_preT_tot:per_pr_dp.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q1_rur:per_pr_dp.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q1_tot:per_pr_dp.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q1_urb:per_pr_dp.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q2_preT_tot:per_pr_dp.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q2_rur:per_pr_dp.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q2_tot:per_pr_dp.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q2_urb:per_pr_dp.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q3_preT_tot:per_pr_dp.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q3_rur:per_pr_dp.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q3_tot:per_pr_dp.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q3_urb:per_pr_dp.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q4_preT_tot:per_pr_dp.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q4_rur:per_pr_dp.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q4_tot:per_pr_dp.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q4_urb:per_pr_dp.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q5_preT_tot:per_pr_dp.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q5_rur:per_pr_dp.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q5_tot:per_pr_dp.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.bry_q5_urb:per_pr_dp.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cba_ep_tot:per_pr_dp.cba_ep_tot} - Benefit-cost ratio -  Domestic Private Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Domestic Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cba_q1_rur:per_pr_dp.cba_q1_rur} - Benefit-cost ratio -  Domestic Private Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Domestic Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cba_q1_tot:per_pr_dp.cba_q1_tot} - Benefit-cost ratio -  Domestic Private Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Domestic Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cba_q1_urb:per_pr_dp.cba_q1_urb} - Benefit-cost ratio -  Domestic Private Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Domestic Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_ep_preT_tot:per_pr_dp.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_ep_tot:per_pr_dp.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_pop_rur:per_pr_dp.cov_pop_rur} - Coverage (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_pop_tot:per_pr_dp.cov_pop_tot} - Coverage (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_pop_urb:per_pr_dp.cov_pop_urb} - Coverage (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q1_preT_tot:per_pr_dp.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q1_rur:per_pr_dp.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q1_tot:per_pr_dp.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q1_urb:per_pr_dp.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q2_preT_tot:per_pr_dp.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q2_rur:per_pr_dp.cov_q2_rur} - Coverage in 2nd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q2_tot:per_pr_dp.cov_q2_tot} - Coverage in 2nd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q2_urb:per_pr_dp.cov_q2_urb} - Coverage in 2nd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q3_preT_tot:per_pr_dp.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q3_rur:per_pr_dp.cov_q3_rur} - Coverage in 3rd quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q3_tot:per_pr_dp.cov_q3_tot} - Coverage in 3rd quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q3_urb:per_pr_dp.cov_q3_urb} - Coverage in 3rd quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q4_preT_tot:per_pr_dp.cov_q4_preT_tot} - Coverage in 4th quintile (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q4_rur:per_pr_dp.cov_q4_rur} - Coverage in 4th quintile (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q4_tot:per_pr_dp.cov_q4_tot} - Coverage in 4th quintile (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q4_urb:per_pr_dp.cov_q4_urb} - Coverage in 4th quintile (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q5_preT_tot:per_pr_dp.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - Domestic Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q5_rur:per_pr_dp.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q5_tot:per_pr_dp.cov_q5_tot} - Coverage in 5th quintile (richest) (%) - Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp.cov_q5_urb:per_pr_dp.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Domestic Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_gini_rur:per_pr_dp_gini_rur} - Gini inequality index reduction (%) -  Domestic Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Domestic Private Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_gini_tot:per_pr_dp_gini_tot} - Gini inequality index reduction (%) -  Domestic Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Domestic Private Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_gini_urb:per_pr_dp_gini_urb} - Gini inequality index reduction (%) -  Domestic Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Domestic Private Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p0_ep_tot:per_pr_dp_p0_ep_tot} - Poverty Headcount reduction (%) -  Domestic Private Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Domestic Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p0_rur:per_pr_dp_p0_rur} - Poverty Headcount reduction (%) -  Domestic Private Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Domestic Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p0_tot:per_pr_dp_p0_tot} - Poverty Headcount reduction (%) -  Domestic Private Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Domestic Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p0_urb:per_pr_dp_p0_urb} - Poverty Headcount reduction (%) -  Domestic Private Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Domestic Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p1_ep_tot:per_pr_dp_p1_ep_tot} - Poverty Gap reduction (%) -  Domestic Private Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Domestic Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p1_rur:per_pr_dp_p1_rur} - Poverty Gap reduction (%) -  Domestic Private Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Domestic Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p1_tot:per_pr_dp_p1_tot} - Poverty Gap reduction (%) -  Domestic Private Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Domestic Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_dp_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_dp_p1_urb:per_pr_dp_p1_urb} - Poverty Gap reduction (%) -  Domestic Private Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Domestic Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_ep_preT_tot:per_pr_ip.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_ep_tot:per_pr_ip.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_pop_rur:per_pr_ip.adq_pop_rur} - Adequacy of benefits (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_pop_tot:per_pr_ip.adq_pop_tot} - Adequacy of benefits (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_pop_urb:per_pr_ip.adq_pop_urb} - Adequacy of benefits (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q1_preT_tot:per_pr_ip.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q1_rur:per_pr_ip.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q1_tot:per_pr_ip.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q1_urb:per_pr_ip.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q2_preT_tot:per_pr_ip.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q2_rur:per_pr_ip.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q2_tot:per_pr_ip.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q2_urb:per_pr_ip.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q3_preT_tot:per_pr_ip.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q3_rur:per_pr_ip.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q3_tot:per_pr_ip.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q3_urb:per_pr_ip.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q4_preT_tot:per_pr_ip.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q4_rur:per_pr_ip.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q4_tot:per_pr_ip.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q4_urb:per_pr_ip.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q5_preT_tot:per_pr_ip.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q5_rur:per_pr_ip.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q5_tot:per_pr_ip.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.adq_q5_urb:per_pr_ip.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_ep_preT_tot:per_pr_ip.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_ep_tot:per_pr_ip.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_pop_rur:per_pr_ip.avt_pop_rur} - Average per capita transfer - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_pop_tot:per_pr_ip.avt_pop_tot} - Average per capita transfer - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_pop_urb:per_pr_ip.avt_pop_urb} - Average per capita transfer - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q1_preT_tot:per_pr_ip.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q1_rur:per_pr_ip.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q1_tot:per_pr_ip.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q1_urb:per_pr_ip.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q2_preT_tot:per_pr_ip.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q2_rur:per_pr_ip.avt_q2_rur} - Average per capita transfer held by 2nd quintile - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q2_tot:per_pr_ip.avt_q2_tot} - Average per capita transfer held by 2nd quintile - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q2_urb:per_pr_ip.avt_q2_urb} - Average per capita transfer held by 2nd quintile - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q3_preT_tot:per_pr_ip.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q3_rur:per_pr_ip.avt_q3_rur} - Average per capita transfer held by 3rd quintile - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q3_tot:per_pr_ip.avt_q3_tot} - Average per capita transfer held by 3rd quintile - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q3_urb:per_pr_ip.avt_q3_urb} - Average per capita transfer held by 3rd quintile - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q4_preT_tot:per_pr_ip.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q4_rur:per_pr_ip.avt_q4_rur} - Average per capita transfer held by 4th quintile - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q4_tot:per_pr_ip.avt_q4_tot} - Average per capita transfer held by 4th quintile - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q4_urb:per_pr_ip.avt_q4_urb} - Average per capita transfer held by 4th quintile - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q5_preT_tot:per_pr_ip.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q5_rur:per_pr_ip.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q5_tot:per_pr_ip.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.avt_q5_urb:per_pr_ip.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  International Private Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_ep_preT_tot:per_pr_ip.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_ep_tot:per_pr_ip.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q1_preT_tot:per_pr_ip.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q1_rur:per_pr_ip.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q1_tot:per_pr_ip.ben_q1_tot} - Benefits incidence in 1st quintile (poorest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q1_urb:per_pr_ip.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q2_preT_tot:per_pr_ip.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q2_rur:per_pr_ip.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q2_tot:per_pr_ip.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q2_urb:per_pr_ip.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q3_preT_tot:per_pr_ip.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q3_rur:per_pr_ip.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q3_tot:per_pr_ip.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q3_urb:per_pr_ip.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q4_preT_tot:per_pr_ip.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q4_rur:per_pr_ip.ben_q4_rur} - Benefits incidence in 4th quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q4_tot:per_pr_ip.ben_q4_tot} - Benefits incidence in 4th quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q4_urb:per_pr_ip.ben_q4_urb} - Benefits incidence in 4th quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q5_preT_tot:per_pr_ip.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q5_rur:per_pr_ip.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q5_tot:per_pr_ip.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.ben_q5_urb:per_pr_ip.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_ep_preT_tot:per_pr_ip.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_ep_tot:per_pr_ip.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q1_preT_tot:per_pr_ip.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q1_rur:per_pr_ip.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q1_tot:per_pr_ip.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q1_urb:per_pr_ip.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q2_preT_tot:per_pr_ip.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q2_rur:per_pr_ip.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q2_tot:per_pr_ip.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q2_urb:per_pr_ip.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q3_preT_tot:per_pr_ip.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q3_rur:per_pr_ip.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q3_tot:per_pr_ip.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q3_urb:per_pr_ip.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q4_preT_tot:per_pr_ip.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q4_rur:per_pr_ip.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q4_tot:per_pr_ip.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q4_urb:per_pr_ip.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q5_preT_tot:per_pr_ip.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q5_rur:per_pr_ip.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q5_tot:per_pr_ip.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.bry_q5_urb:per_pr_ip.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cba_ep_tot:per_pr_ip.cba_ep_tot} - Benefit-cost ratio -  International Private Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in International Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cba_q1_rur:per_pr_ip.cba_q1_rur} - Benefit-cost ratio -  International Private Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in International Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cba_q1_tot:per_pr_ip.cba_q1_tot} - Benefit-cost ratio -  International Private Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in International Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cba_q1_urb:per_pr_ip.cba_q1_urb} - Benefit-cost ratio -  International Private Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in International Private Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_ep_preT_tot:per_pr_ip.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_ep_tot:per_pr_ip.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_pop_rur:per_pr_ip.cov_pop_rur} - Coverage (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_pop_tot:per_pr_ip.cov_pop_tot} - Coverage (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_pop_urb:per_pr_ip.cov_pop_urb} - Coverage (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q1_preT_tot:per_pr_ip.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q1_rur:per_pr_ip.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q1_tot:per_pr_ip.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q1_urb:per_pr_ip.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q2_preT_tot:per_pr_ip.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q2_rur:per_pr_ip.cov_q2_rur} - Coverage in 2nd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q2_tot:per_pr_ip.cov_q2_tot} - Coverage in 2nd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q2_urb:per_pr_ip.cov_q2_urb} - Coverage in 2nd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q3_preT_tot:per_pr_ip.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q3_rur:per_pr_ip.cov_q3_rur} - Coverage in 3rd quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q3_tot:per_pr_ip.cov_q3_tot} - Coverage in 3rd quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q3_urb:per_pr_ip.cov_q3_urb} - Coverage in 3rd quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q4_preT_tot:per_pr_ip.cov_q4_preT_tot} - Coverage in 4th quintile (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q4_rur:per_pr_ip.cov_q4_rur} - Coverage in 4th quintile (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q4_tot:per_pr_ip.cov_q4_tot} - Coverage in 4th quintile (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q4_urb:per_pr_ip.cov_q4_urb} - Coverage in 4th quintile (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q5_preT_tot:per_pr_ip.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - International Private Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q5_rur:per_pr_ip.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q5_tot:per_pr_ip.cov_q5_tot} - Coverage in 5th quintile (richest) (%) - International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip.cov_q5_urb:per_pr_ip.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in International Private Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_gini_rur:per_pr_ip_gini_rur} - Gini inequality index reduction (%) -  International Private Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to International Private Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_gini_tot:per_pr_ip_gini_tot} - Gini inequality index reduction (%) -  International Private Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to International Private Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_gini_urb:per_pr_ip_gini_urb} - Gini inequality index reduction (%) -  International Private Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to International Private Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p0_ep_tot:per_pr_ip_p0_ep_tot} - Poverty Headcount reduction (%) -  International Private Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to International Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p0_rur:per_pr_ip_p0_rur} - Poverty Headcount reduction (%) -  International Private Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to International Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p0_tot:per_pr_ip_p0_tot} - Poverty Headcount reduction (%) -  International Private Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to International Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p0_urb:per_pr_ip_p0_urb} - Poverty Headcount reduction (%) -  International Private Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to International Private Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p1_ep_tot:per_pr_ip_p1_ep_tot} - Poverty Gap reduction (%) -  International Private Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to International Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p1_rur:per_pr_ip_p1_rur} - Poverty Gap reduction (%) -  International Private Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to International Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p1_tot:per_pr_ip_p1_tot} - Poverty Gap reduction (%) -  International Private Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to International Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_pr_ip_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_pr_ip_p1_urb:per_pr_ip_p1_urb} - Poverty Gap reduction (%) -  International Private Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to International Private Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_ep_preT_tot:per_sa_allsa.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_ep_tot:per_sa_allsa.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_pop_rur:per_sa_allsa.adq_pop_rur} - Adequacy of benefits (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_pop_tot:per_sa_allsa.adq_pop_tot} - Adequacy of social safety net programs (% of total welfare of beneficiary households)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Adequacy of social safety net programs is measured by the total transfer amount received by the population participating in social safety net programs as a share of their total welfare. Welfare is defined as the total income or total expenditu{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_pop_urb:per_sa_allsa.adq_pop_urb} - Adequacy of benefits (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q1_preT_tot:per_sa_allsa.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q1_rur:per_sa_allsa.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q1_tot:per_sa_allsa.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q1_urb:per_sa_allsa.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q2_preT_tot:per_sa_allsa.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q2_rur:per_sa_allsa.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q2_tot:per_sa_allsa.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q2_urb:per_sa_allsa.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q3_preT_tot:per_sa_allsa.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q3_rur:per_sa_allsa.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q3_tot:per_sa_allsa.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q3_urb:per_sa_allsa.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q4_preT_tot:per_sa_allsa.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q4_rur:per_sa_allsa.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q4_tot:per_sa_allsa.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q4_urb:per_sa_allsa.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q5_preT_tot:per_sa_allsa.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q5_rur:per_sa_allsa.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q5_tot:per_sa_allsa.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.adq_q5_urb:per_sa_allsa.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_ep_preT_tot:per_sa_allsa.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - All Social Assistance  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_ep_tot:per_sa_allsa.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_pop_rur:per_sa_allsa.avt_pop_rur} - Average per capita transfer - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_pop_tot:per_sa_allsa.avt_pop_tot} - Average per capita transfer - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_pop_urb:per_sa_allsa.avt_pop_urb} - Average per capita transfer - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q1_preT_tot:per_sa_allsa.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q1_rur:per_sa_allsa.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q1_tot:per_sa_allsa.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q1_urb:per_sa_allsa.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q2_preT_tot:per_sa_allsa.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q2_rur:per_sa_allsa.avt_q2_rur} - Average per capita transfer held by 2nd quintile - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q2_tot:per_sa_allsa.avt_q2_tot} - Average per capita transfer held by 2nd quintile - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q2_urb:per_sa_allsa.avt_q2_urb} - Average per capita transfer held by 2nd quintile - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q3_preT_tot:per_sa_allsa.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q3_rur:per_sa_allsa.avt_q3_rur} - Average per capita transfer held by 3rd quintile - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q3_tot:per_sa_allsa.avt_q3_tot} - Average per capita transfer held by 3rd quintile - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q3_urb:per_sa_allsa.avt_q3_urb} - Average per capita transfer held by 3rd quintile - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q4_preT_tot:per_sa_allsa.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q4_rur:per_sa_allsa.avt_q4_rur} - Average per capita transfer held by 4th quintile - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q4_tot:per_sa_allsa.avt_q4_tot} - Average per capita transfer held by 4th quintile - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q4_urb:per_sa_allsa.avt_q4_urb} - Average per capita transfer held by 4th quintile - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q5_preT_tot:per_sa_allsa.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q5_rur:per_sa_allsa.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q5_tot:per_sa_allsa.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.avt_q5_urb:per_sa_allsa.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Assistance programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_ep_preT_tot:per_sa_allsa.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_ep_tot:per_sa_allsa.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q1_preT_tot:per_sa_allsa.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q1_rur:per_sa_allsa.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q1_tot:per_sa_allsa.ben_q1_tot} - Benefit incidence of social safety net programs to poorest quintile (% of total safety net benefits)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Benefit incidence of social safety net programs to poorest quintile shows the percentage of total social safety net benefits received by the poorest 20% of the population. Social safety net programs include cash transfers and last resort progr{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q1_urb:per_sa_allsa.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q2_preT_tot:per_sa_allsa.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q2_rur:per_sa_allsa.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q2_tot:per_sa_allsa.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q2_urb:per_sa_allsa.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q3_preT_tot:per_sa_allsa.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q3_rur:per_sa_allsa.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q3_tot:per_sa_allsa.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q3_urb:per_sa_allsa.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q4_preT_tot:per_sa_allsa.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q4_rur:per_sa_allsa.ben_q4_rur} - Benefits incidence in 4th quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q4_tot:per_sa_allsa.ben_q4_tot} - Benefits incidence in 4th quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q4_urb:per_sa_allsa.ben_q4_urb} - Benefits incidence in 4th quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q5_preT_tot:per_sa_allsa.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q5_rur:per_sa_allsa.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q5_tot:per_sa_allsa.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.ben_q5_urb:per_sa_allsa.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_ep_preT_tot:per_sa_allsa.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_ep_tot:per_sa_allsa.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q1_preT_tot:per_sa_allsa.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q1_rur:per_sa_allsa.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q1_tot:per_sa_allsa.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q1_urb:per_sa_allsa.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q2_preT_tot:per_sa_allsa.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q2_rur:per_sa_allsa.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q2_tot:per_sa_allsa.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q2_urb:per_sa_allsa.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q3_preT_tot:per_sa_allsa.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q3_rur:per_sa_allsa.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q3_tot:per_sa_allsa.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q3_urb:per_sa_allsa.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q4_preT_tot:per_sa_allsa.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q4_rur:per_sa_allsa.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q4_tot:per_sa_allsa.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q4_urb:per_sa_allsa.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q5_preT_tot:per_sa_allsa.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q5_rur:per_sa_allsa.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q5_tot:per_sa_allsa.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.bry_q5_urb:per_sa_allsa.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cba_ep_tot:per_sa_allsa.cba_ep_tot} - Benefit-cost ratio -  All Social Assistance -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Social Assistance programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cba_q1_rur:per_sa_allsa.cba_q1_rur} - Benefit-cost ratio -  All Social Assistance -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Social Assistance programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cba_q1_tot:per_sa_allsa.cba_q1_tot} - Benefit-cost ratio -  All Social Assistance -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Social Assistance programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cba_q1_urb:per_sa_allsa.cba_q1_urb} - Benefit-cost ratio -  All Social Assistance - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Social Assistance programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_ep_preT_tot:per_sa_allsa.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_ep_tot:per_sa_allsa.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_pop_rur:per_sa_allsa.cov_pop_rur} - Coverage (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_pop_tot:per_sa_allsa.cov_pop_tot} - Coverage of social safety net programs (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of social safety net programs shows the percentage of population participating in cash transfers and last resort programs, noncontributory social pensions, other cash transfers programs (child, family and orphan allowances, birth and{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_pop_urb:per_sa_allsa.cov_pop_urb} - Coverage (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q1_preT_tot:per_sa_allsa.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q1_rur:per_sa_allsa.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q1_tot:per_sa_allsa.cov_q1_tot} - Coverage of social safety net programs in poorest quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of social safety net programs shows the percentage of population participating in cash transfers and last resort programs, noncontributory social pensions, other cash transfers programs (child, family and orphan allowances, birth and{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q1_urb:per_sa_allsa.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q2_preT_tot:per_sa_allsa.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q2_rur:per_sa_allsa.cov_q2_rur} - Coverage in 2nd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q2_tot:per_sa_allsa.cov_q2_tot} - Coverage of social safety net programs in 2nd quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of social safety net programs shows the percentage of population participating in cash transfers and last resort programs, noncontributory social pensions, other cash transfers programs (child, family and orphan allowances, birth and{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q2_urb:per_sa_allsa.cov_q2_urb} - Coverage in 2nd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q3_preT_tot:per_sa_allsa.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q3_rur:per_sa_allsa.cov_q3_rur} - Coverage in 3rd quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q3_tot:per_sa_allsa.cov_q3_tot} - Coverage of social safety net programs in 3rd quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of social safety net programs shows the percentage of population participating in cash transfers and last resort programs, noncontributory social pensions, other cash transfers programs (child, family and orphan allowances, birth and{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q3_urb:per_sa_allsa.cov_q3_urb} - Coverage in 3rd quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q4_preT_tot:per_sa_allsa.cov_q4_preT_tot} - Coverage in 4th quintile (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q4_rur:per_sa_allsa.cov_q4_rur} - Coverage in 4th quintile (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q4_tot:per_sa_allsa.cov_q4_tot} - Coverage of social safety net programs in 4th quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of social safety net programs shows the percentage of population participating in cash transfers and last resort programs, noncontributory social pensions, other cash transfers programs (child, family and orphan allowances, birth and{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q4_urb:per_sa_allsa.cov_q4_urb} - Coverage in 4th quintile (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q5_preT_tot:per_sa_allsa.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - All Social Assistance (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q5_rur:per_sa_allsa.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q5_tot:per_sa_allsa.cov_q5_tot} - Coverage of social safety net programs in richest quintile (% of population)}}

{synopt:{opt Source}}02 World Development Indicators{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Coverage of social safety net programs shows the percentage of population participating in cash transfers and last resort programs, noncontributory social pensions, other cash transfers programs (child, family and orphan allowances, birth and{p_end}

{synopt:{opt Source Organization}}ASPIRE: The Atlas of Social Protection - Indicators of Resilience and Equity, World Bank (WB), uri: datatopics.worldbank.org/aspire/, note: Data are based on national representative household surveys.{p_end}


{synoptline}
{marker topicid_per_sa_allsa.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa.cov_q5_urb:per_sa_allsa.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Social Assistance programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_gini_rur:per_sa_allsa_gini_rur} - Gini inequality index reduction (%) -  All Social Assistance -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Social Assistance programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_gini_tot:per_sa_allsa_gini_tot} - Gini inequality index reduction (%) -  All Social Assistance}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Social Assistance programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_gini_urb:per_sa_allsa_gini_urb} - Gini inequality index reduction (%) -  All Social Assistance -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Social Assistance programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p0_ep_tot:per_sa_allsa_p0_ep_tot} - Poverty Headcount reduction (%) -  All Social Assistance -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Social Assistance programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p0_rur:per_sa_allsa_p0_rur} - Poverty Headcount reduction (%) -  All Social Assistance -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Social Assistance programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p0_tot:per_sa_allsa_p0_tot} - Poverty Headcount reduction (%) -  All Social Assistance -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Social Assistance programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p0_urb:per_sa_allsa_p0_urb} - Poverty Headcount reduction (%) -  All Social Assistance - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Social Assistance programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p1_ep_tot:per_sa_allsa_p1_ep_tot} - Poverty Gap reduction (%) -  All Social Assistance -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Social Assistance programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p1_rur:per_sa_allsa_p1_rur} - Poverty Gap reduction (%) -  All Social Assistance -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Social Assistance programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p1_tot:per_sa_allsa_p1_tot} - Poverty Gap reduction (%) -  All Social Assistance -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Social Assistance programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_allsa_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_allsa_p1_urb:per_sa_allsa_p1_urb} - Poverty Gap reduction (%) -  All Social Assistance - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Social Assistance programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_ep_preT_tot:per_sa_ct.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_ep_tot:per_sa_ct.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_pop_rur:per_sa_ct.adq_pop_rur} - Adequacy of benefits (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_pop_tot:per_sa_ct.adq_pop_tot} - Adequacy of benefits (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_pop_urb:per_sa_ct.adq_pop_urb} - Adequacy of benefits (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q1_preT_tot:per_sa_ct.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q1_rur:per_sa_ct.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q1_tot:per_sa_ct.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q1_urb:per_sa_ct.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q2_preT_tot:per_sa_ct.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q2_rur:per_sa_ct.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q2_tot:per_sa_ct.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q2_urb:per_sa_ct.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q3_preT_tot:per_sa_ct.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q3_rur:per_sa_ct.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q3_tot:per_sa_ct.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q3_urb:per_sa_ct.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q4_preT_tot:per_sa_ct.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q4_rur:per_sa_ct.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q4_tot:per_sa_ct.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q4_urb:per_sa_ct.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q5_preT_tot:per_sa_ct.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q5_rur:per_sa_ct.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q5_tot:per_sa_ct.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.adq_q5_urb:per_sa_ct.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_ep_preT_tot:per_sa_ct.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Unconditional Cash Transfers  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_ep_tot:per_sa_ct.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_pop_rur:per_sa_ct.avt_pop_rur} - Average per capita transfer - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_pop_tot:per_sa_ct.avt_pop_tot} - Average per capita transfer - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_pop_urb:per_sa_ct.avt_pop_urb} - Average per capita transfer - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q1_preT_tot:per_sa_ct.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q1_rur:per_sa_ct.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q1_tot:per_sa_ct.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q1_urb:per_sa_ct.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q2_preT_tot:per_sa_ct.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q2_rur:per_sa_ct.avt_q2_rur} - Average per capita transfer held by 2nd quintile - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q2_tot:per_sa_ct.avt_q2_tot} - Average per capita transfer held by 2nd quintile - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q2_urb:per_sa_ct.avt_q2_urb} - Average per capita transfer held by 2nd quintile - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q3_preT_tot:per_sa_ct.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q3_rur:per_sa_ct.avt_q3_rur} - Average per capita transfer held by 3rd quintile - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q3_tot:per_sa_ct.avt_q3_tot} - Average per capita transfer held by 3rd quintile - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q3_urb:per_sa_ct.avt_q3_urb} - Average per capita transfer held by 3rd quintile - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q4_preT_tot:per_sa_ct.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q4_rur:per_sa_ct.avt_q4_rur} - Average per capita transfer held by 4th quintile - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q4_tot:per_sa_ct.avt_q4_tot} - Average per capita transfer held by 4th quintile - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q4_urb:per_sa_ct.avt_q4_urb} - Average per capita transfer held by 4th quintile - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q5_preT_tot:per_sa_ct.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q5_rur:per_sa_ct.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q5_tot:per_sa_ct.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.avt_q5_urb:per_sa_ct.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Cash Transfers programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_ep_preT_tot:per_sa_ct.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_ep_tot:per_sa_ct.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q1_preT_tot:per_sa_ct.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q1_rur:per_sa_ct.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q1_tot:per_sa_ct.ben_q1_tot} - Benefits incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q1_urb:per_sa_ct.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q2_preT_tot:per_sa_ct.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q2_rur:per_sa_ct.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q2_tot:per_sa_ct.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q2_urb:per_sa_ct.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q3_preT_tot:per_sa_ct.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q3_rur:per_sa_ct.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q3_tot:per_sa_ct.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q3_urb:per_sa_ct.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q4_preT_tot:per_sa_ct.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q4_rur:per_sa_ct.ben_q4_rur} - Benefits incidence in 4th quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q4_tot:per_sa_ct.ben_q4_tot} - Benefits incidence in 4th quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q4_urb:per_sa_ct.ben_q4_urb} - Benefits incidence in 4th quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q5_preT_tot:per_sa_ct.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q5_rur:per_sa_ct.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q5_tot:per_sa_ct.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.ben_q5_urb:per_sa_ct.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_ep_preT_tot:per_sa_ct.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_ep_tot:per_sa_ct.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q1_preT_tot:per_sa_ct.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q1_rur:per_sa_ct.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q1_tot:per_sa_ct.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q1_urb:per_sa_ct.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q2_preT_tot:per_sa_ct.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q2_rur:per_sa_ct.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q2_tot:per_sa_ct.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q2_urb:per_sa_ct.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q3_preT_tot:per_sa_ct.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q3_rur:per_sa_ct.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q3_tot:per_sa_ct.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q3_urb:per_sa_ct.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q4_preT_tot:per_sa_ct.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q4_rur:per_sa_ct.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q4_tot:per_sa_ct.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q4_urb:per_sa_ct.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q5_preT_tot:per_sa_ct.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q5_rur:per_sa_ct.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q5_tot:per_sa_ct.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.bry_q5_urb:per_sa_ct.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cba_ep_tot:per_sa_ct.cba_ep_tot} - Benefit-cost ratio -  Unconditional Cash Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Cash Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cba_q1_rur:per_sa_ct.cba_q1_rur} - Benefit-cost ratio -  Unconditional Cash Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Cash Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cba_q1_tot:per_sa_ct.cba_q1_tot} - Benefit-cost ratio -  Unconditional Cash Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Cash Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cba_q1_urb:per_sa_ct.cba_q1_urb} - Benefit-cost ratio -  Unconditional Cash Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Cash Transfers programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_ep_preT_tot:per_sa_ct.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_ep_tot:per_sa_ct.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_pop_rur:per_sa_ct.cov_pop_rur} - Coverage (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_pop_tot:per_sa_ct.cov_pop_tot} - Coverage (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_pop_urb:per_sa_ct.cov_pop_urb} - Coverage (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q1_preT_tot:per_sa_ct.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q1_rur:per_sa_ct.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q1_tot:per_sa_ct.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q1_urb:per_sa_ct.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q2_preT_tot:per_sa_ct.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q2_rur:per_sa_ct.cov_q2_rur} - Coverage in 2nd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q2_tot:per_sa_ct.cov_q2_tot} - Coverage in 2nd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q2_urb:per_sa_ct.cov_q2_urb} - Coverage in 2nd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q3_preT_tot:per_sa_ct.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q3_rur:per_sa_ct.cov_q3_rur} - Coverage in 3rd quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q3_tot:per_sa_ct.cov_q3_tot} - Coverage in 3rd quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q3_urb:per_sa_ct.cov_q3_urb} - Coverage in 3rd quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q4_preT_tot:per_sa_ct.cov_q4_preT_tot} - Coverage in 4th quintile (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q4_rur:per_sa_ct.cov_q4_rur} - Coverage in 4th quintile (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q4_tot:per_sa_ct.cov_q4_tot} - Coverage in 4th quintile (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q4_urb:per_sa_ct.cov_q4_urb} - Coverage in 4th quintile (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q5_preT_tot:per_sa_ct.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - Unconditional Cash Transfers (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q5_rur:per_sa_ct.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q5_tot:per_sa_ct.cov_q5_tot} - Coverage in 5th quintile (richest) (%) - Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct.cov_q5_urb:per_sa_ct.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Cash Transfers programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_gini_rur:per_sa_ct_gini_rur} - Gini inequality index reduction (%) -  Unconditional Cash Transfers -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Cash Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_gini_tot:per_sa_ct_gini_tot} - Gini inequality index reduction (%) -  Unconditional Cash Transfers}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Cash Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_gini_urb:per_sa_ct_gini_urb} - Gini inequality index reduction (%) -  Unconditional Cash Transfers -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Cash Transfers programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p0_ep_tot:per_sa_ct_p0_ep_tot} - Poverty Headcount reduction (%) -  Unconditional Cash Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Cash Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p0_rur:per_sa_ct_p0_rur} - Poverty Headcount reduction (%) -  Unconditional Cash Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Cash Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p0_tot:per_sa_ct_p0_tot} - Poverty Headcount reduction (%) -  Unconditional Cash Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Cash Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p0_urb:per_sa_ct_p0_urb} - Poverty Headcount reduction (%) -  Unconditional Cash Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Cash Transfers programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p1_ep_tot:per_sa_ct_p1_ep_tot} - Poverty Gap reduction (%) -  Unconditional Cash Transfers -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Cash Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p1_rur:per_sa_ct_p1_rur} - Poverty Gap reduction (%) -  Unconditional Cash Transfers -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Cash Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p1_tot:per_sa_ct_p1_tot} - Poverty Gap reduction (%) -  Unconditional Cash Transfers -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Cash Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ct_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ct_p1_urb:per_sa_ct_p1_urb} - Poverty Gap reduction (%) -  Unconditional Cash Transfers - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Cash Transfers programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_ep_preT_tot:per_sa_ik.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_ep_tot:per_sa_ik.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_pop_rur:per_sa_ik.adq_pop_rur} - Adequacy of benefits (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_pop_tot:per_sa_ik.adq_pop_tot} - Adequacy of benefits (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_pop_urb:per_sa_ik.adq_pop_urb} - Adequacy of benefits (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q1_preT_tot:per_sa_ik.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q1_rur:per_sa_ik.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q1_tot:per_sa_ik.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q1_urb:per_sa_ik.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q2_preT_tot:per_sa_ik.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q2_rur:per_sa_ik.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q2_tot:per_sa_ik.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q2_urb:per_sa_ik.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q3_preT_tot:per_sa_ik.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q3_rur:per_sa_ik.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q3_tot:per_sa_ik.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q3_urb:per_sa_ik.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q4_preT_tot:per_sa_ik.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q4_rur:per_sa_ik.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q4_tot:per_sa_ik.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q4_urb:per_sa_ik.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q5_preT_tot:per_sa_ik.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q5_rur:per_sa_ik.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q5_tot:per_sa_ik.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.adq_q5_urb:per_sa_ik.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_ep_preT_tot:per_sa_ik.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_ep_tot:per_sa_ik.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_pop_rur:per_sa_ik.avt_pop_rur} - Average per capita transfer - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_pop_tot:per_sa_ik.avt_pop_tot} - Average per capita transfer - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_pop_urb:per_sa_ik.avt_pop_urb} - Average per capita transfer - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q1_preT_tot:per_sa_ik.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q1_rur:per_sa_ik.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q1_tot:per_sa_ik.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q1_urb:per_sa_ik.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q2_preT_tot:per_sa_ik.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q2_rur:per_sa_ik.avt_q2_rur} - Average per capita transfer held by 2nd quintile - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q2_tot:per_sa_ik.avt_q2_tot} - Average per capita transfer held by 2nd quintile - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q2_urb:per_sa_ik.avt_q2_urb} - Average per capita transfer held by 2nd quintile - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q3_preT_tot:per_sa_ik.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q3_rur:per_sa_ik.avt_q3_rur} - Average per capita transfer held by 3rd quintile - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q3_tot:per_sa_ik.avt_q3_tot} - Average per capita transfer held by 3rd quintile - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q3_urb:per_sa_ik.avt_q3_urb} - Average per capita transfer held by 3rd quintile - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q4_preT_tot:per_sa_ik.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q4_rur:per_sa_ik.avt_q4_rur} - Average per capita transfer held by 4th quintile - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q4_tot:per_sa_ik.avt_q4_tot} - Average per capita transfer held by 4th quintile - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q4_urb:per_sa_ik.avt_q4_urb} - Average per capita transfer held by 4th quintile - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q5_preT_tot:per_sa_ik.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q5_rur:per_sa_ik.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q5_tot:per_sa_ik.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.avt_q5_urb:per_sa_ik.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  In-Kind programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_ep_preT_tot:per_sa_ik.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_ep_tot:per_sa_ik.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q1_preT_tot:per_sa_ik.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q1_rur:per_sa_ik.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q1_tot:per_sa_ik.ben_q1_tot} - Benefits incidence in 1st quintile (poorest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q1_urb:per_sa_ik.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q2_preT_tot:per_sa_ik.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q2_rur:per_sa_ik.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q2_tot:per_sa_ik.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q2_urb:per_sa_ik.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q3_preT_tot:per_sa_ik.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q3_rur:per_sa_ik.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q3_tot:per_sa_ik.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q3_urb:per_sa_ik.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q4_preT_tot:per_sa_ik.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q4_rur:per_sa_ik.ben_q4_rur} - Benefits incidence in 4th quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q4_tot:per_sa_ik.ben_q4_tot} - Benefits incidence in 4th quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q4_urb:per_sa_ik.ben_q4_urb} - Benefits incidence in 4th quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q5_preT_tot:per_sa_ik.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q5_rur:per_sa_ik.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q5_tot:per_sa_ik.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.ben_q5_urb:per_sa_ik.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_ep_preT_tot:per_sa_ik.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_ep_tot:per_sa_ik.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q1_preT_tot:per_sa_ik.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q1_rur:per_sa_ik.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q1_tot:per_sa_ik.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q1_urb:per_sa_ik.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q2_preT_tot:per_sa_ik.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q2_rur:per_sa_ik.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q2_tot:per_sa_ik.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q2_urb:per_sa_ik.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q3_preT_tot:per_sa_ik.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q3_rur:per_sa_ik.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q3_tot:per_sa_ik.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q3_urb:per_sa_ik.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q4_preT_tot:per_sa_ik.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q4_rur:per_sa_ik.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q4_tot:per_sa_ik.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q4_urb:per_sa_ik.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q5_preT_tot:per_sa_ik.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q5_rur:per_sa_ik.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q5_tot:per_sa_ik.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.bry_q5_urb:per_sa_ik.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cba_ep_tot:per_sa_ik.cba_ep_tot} - Benefit-cost ratio -  In-Kind -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in In-Kind programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cba_q1_rur:per_sa_ik.cba_q1_rur} - Benefit-cost ratio -  In-Kind -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in In-Kind programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cba_q1_tot:per_sa_ik.cba_q1_tot} - Benefit-cost ratio -  In-Kind -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in In-Kind programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cba_q1_urb:per_sa_ik.cba_q1_urb} - Benefit-cost ratio -  In-Kind - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in In-Kind programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_ep_preT_tot:per_sa_ik.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_ep_tot:per_sa_ik.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_pop_rur:per_sa_ik.cov_pop_rur} - Coverage (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_pop_tot:per_sa_ik.cov_pop_tot} - Coverage (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_pop_urb:per_sa_ik.cov_pop_urb} - Coverage (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q1_preT_tot:per_sa_ik.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q1_rur:per_sa_ik.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q1_tot:per_sa_ik.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q1_urb:per_sa_ik.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q2_preT_tot:per_sa_ik.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q2_rur:per_sa_ik.cov_q2_rur} - Coverage in 2nd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q2_tot:per_sa_ik.cov_q2_tot} - Coverage in 2nd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q2_urb:per_sa_ik.cov_q2_urb} - Coverage in 2nd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q3_preT_tot:per_sa_ik.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q3_rur:per_sa_ik.cov_q3_rur} - Coverage in 3rd quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q3_tot:per_sa_ik.cov_q3_tot} - Coverage in 3rd quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q3_urb:per_sa_ik.cov_q3_urb} - Coverage in 3rd quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q4_preT_tot:per_sa_ik.cov_q4_preT_tot} - Coverage in 4th quintile (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q4_rur:per_sa_ik.cov_q4_rur} - Coverage in 4th quintile (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q4_tot:per_sa_ik.cov_q4_tot} - Coverage in 4th quintile (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q4_urb:per_sa_ik.cov_q4_urb} - Coverage in 4th quintile (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q5_preT_tot:per_sa_ik.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - In-Kind (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q5_rur:per_sa_ik.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q5_tot:per_sa_ik.cov_q5_tot} - Coverage in 5th quintile (richest) (%) - In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik.cov_q5_urb:per_sa_ik.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in In-Kind programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_gini_rur:per_sa_ik_gini_rur} - Gini inequality index reduction (%) -  In-Kind -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to In-Kind programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_gini_tot:per_sa_ik_gini_tot} - Gini inequality index reduction (%) -  In-Kind}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to In-Kind programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_gini_urb:per_sa_ik_gini_urb} - Gini inequality index reduction (%) -  In-Kind -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to In-Kind programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p0_ep_tot:per_sa_ik_p0_ep_tot} - Poverty Headcount reduction (%) -  In-Kind -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to In-Kind programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p0_rur:per_sa_ik_p0_rur} - Poverty Headcount reduction (%) -  In-Kind -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to In-Kind programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p0_tot:per_sa_ik_p0_tot} - Poverty Headcount reduction (%) -  In-Kind -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to In-Kind programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p0_urb:per_sa_ik_p0_urb} - Poverty Headcount reduction (%) -  In-Kind - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to In-Kind programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p1_ep_tot:per_sa_ik_p1_ep_tot} - Poverty Gap reduction (%) -  In-Kind -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to In-Kind programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p1_rur:per_sa_ik_p1_rur} - Poverty Gap reduction (%) -  In-Kind -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to In-Kind programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p1_tot:per_sa_ik_p1_tot} - Poverty Gap reduction (%) -  In-Kind -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to In-Kind programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_ik_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_ik_p1_urb:per_sa_ik_p1_urb} - Poverty Gap reduction (%) -  In-Kind - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to In-Kind programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_ep_preT_tot:per_sa_pw.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_ep_tot:per_sa_pw.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_pop_rur:per_sa_pw.adq_pop_rur} - Adequacy of benefits (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_pop_tot:per_sa_pw.adq_pop_tot} - Adequacy of benefits (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_pop_urb:per_sa_pw.adq_pop_urb} - Adequacy of benefits (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q1_preT_tot:per_sa_pw.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q1_rur:per_sa_pw.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q1_tot:per_sa_pw.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q1_urb:per_sa_pw.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q2_preT_tot:per_sa_pw.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q2_rur:per_sa_pw.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q2_tot:per_sa_pw.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q2_urb:per_sa_pw.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q3_preT_tot:per_sa_pw.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q3_rur:per_sa_pw.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q3_tot:per_sa_pw.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q3_urb:per_sa_pw.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q4_preT_tot:per_sa_pw.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q4_rur:per_sa_pw.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q4_tot:per_sa_pw.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q4_urb:per_sa_pw.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q5_preT_tot:per_sa_pw.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q5_rur:per_sa_pw.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q5_tot:per_sa_pw.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.adq_q5_urb:per_sa_pw.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_ep_preT_tot:per_sa_pw.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_ep_tot:per_sa_pw.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_pop_rur:per_sa_pw.avt_pop_rur} - Average per capita transfer - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_pop_tot:per_sa_pw.avt_pop_tot} - Average per capita transfer - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_pop_urb:per_sa_pw.avt_pop_urb} - Average per capita transfer - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q1_preT_tot:per_sa_pw.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q1_rur:per_sa_pw.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q1_tot:per_sa_pw.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q1_urb:per_sa_pw.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q2_preT_tot:per_sa_pw.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q2_rur:per_sa_pw.avt_q2_rur} - Average per capita transfer held by 2nd quintile - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q2_tot:per_sa_pw.avt_q2_tot} - Average per capita transfer held by 2nd quintile - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q2_urb:per_sa_pw.avt_q2_urb} - Average per capita transfer held by 2nd quintile - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q3_preT_tot:per_sa_pw.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q3_rur:per_sa_pw.avt_q3_rur} - Average per capita transfer held by 3rd quintile - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q3_tot:per_sa_pw.avt_q3_tot} - Average per capita transfer held by 3rd quintile - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q3_urb:per_sa_pw.avt_q3_urb} - Average per capita transfer held by 3rd quintile - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q4_preT_tot:per_sa_pw.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q4_rur:per_sa_pw.avt_q4_rur} - Average per capita transfer held by 4th quintile - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q4_tot:per_sa_pw.avt_q4_tot} - Average per capita transfer held by 4th quintile - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q4_urb:per_sa_pw.avt_q4_urb} - Average per capita transfer held by 4th quintile - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q5_preT_tot:per_sa_pw.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q5_rur:per_sa_pw.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q5_tot:per_sa_pw.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.avt_q5_urb:per_sa_pw.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Public Works programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_ep_preT_tot:per_sa_pw.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_ep_tot:per_sa_pw.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q1_preT_tot:per_sa_pw.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q1_rur:per_sa_pw.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q1_tot:per_sa_pw.ben_q1_tot} - Benefits incidence in 1st quintile (poorest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q1_urb:per_sa_pw.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q2_preT_tot:per_sa_pw.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q2_rur:per_sa_pw.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q2_tot:per_sa_pw.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q2_urb:per_sa_pw.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q3_preT_tot:per_sa_pw.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q3_rur:per_sa_pw.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q3_tot:per_sa_pw.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q3_urb:per_sa_pw.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q4_preT_tot:per_sa_pw.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q4_rur:per_sa_pw.ben_q4_rur} - Benefits incidence in 4th quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q4_tot:per_sa_pw.ben_q4_tot} - Benefits incidence in 4th quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q4_urb:per_sa_pw.ben_q4_urb} - Benefits incidence in 4th quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q5_preT_tot:per_sa_pw.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q5_rur:per_sa_pw.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q5_tot:per_sa_pw.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.ben_q5_urb:per_sa_pw.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_ep_preT_tot:per_sa_pw.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_ep_tot:per_sa_pw.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q1_preT_tot:per_sa_pw.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q1_rur:per_sa_pw.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q1_tot:per_sa_pw.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q1_urb:per_sa_pw.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q2_preT_tot:per_sa_pw.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q2_rur:per_sa_pw.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q2_tot:per_sa_pw.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q2_urb:per_sa_pw.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q3_preT_tot:per_sa_pw.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q3_rur:per_sa_pw.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q3_tot:per_sa_pw.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q3_urb:per_sa_pw.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q4_preT_tot:per_sa_pw.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q4_rur:per_sa_pw.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q4_tot:per_sa_pw.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q4_urb:per_sa_pw.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q5_preT_tot:per_sa_pw.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q5_rur:per_sa_pw.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q5_tot:per_sa_pw.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.bry_q5_urb:per_sa_pw.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cba_ep_tot:per_sa_pw.cba_ep_tot} - Benefit-cost ratio -  Public Works -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Public Works programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cba_q1_rur:per_sa_pw.cba_q1_rur} - Benefit-cost ratio -  Public Works -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Public Works programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cba_q1_tot:per_sa_pw.cba_q1_tot} - Benefit-cost ratio -  Public Works -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Public Works programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cba_q1_urb:per_sa_pw.cba_q1_urb} - Benefit-cost ratio -  Public Works - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in Public Works programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_ep_preT_tot:per_sa_pw.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_ep_tot:per_sa_pw.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_pop_rur:per_sa_pw.cov_pop_rur} - Coverage (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_pop_tot:per_sa_pw.cov_pop_tot} - Coverage (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_pop_urb:per_sa_pw.cov_pop_urb} - Coverage (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q1_preT_tot:per_sa_pw.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q1_rur:per_sa_pw.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q1_tot:per_sa_pw.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q1_urb:per_sa_pw.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q2_preT_tot:per_sa_pw.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q2_rur:per_sa_pw.cov_q2_rur} - Coverage in 2nd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q2_tot:per_sa_pw.cov_q2_tot} - Coverage in 2nd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q2_urb:per_sa_pw.cov_q2_urb} - Coverage in 2nd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q3_preT_tot:per_sa_pw.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q3_rur:per_sa_pw.cov_q3_rur} - Coverage in 3rd quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q3_tot:per_sa_pw.cov_q3_tot} - Coverage in 3rd quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q3_urb:per_sa_pw.cov_q3_urb} - Coverage in 3rd quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q4_preT_tot:per_sa_pw.cov_q4_preT_tot} - Coverage in 4th quintile (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q4_rur:per_sa_pw.cov_q4_rur} - Coverage in 4th quintile (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q4_tot:per_sa_pw.cov_q4_tot} - Coverage in 4th quintile (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q4_urb:per_sa_pw.cov_q4_urb} - Coverage in 4th quintile (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q5_preT_tot:per_sa_pw.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - Public Works (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q5_rur:per_sa_pw.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q5_tot:per_sa_pw.cov_q5_tot} - Coverage in 5th quintile (richest) (%) - Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw.cov_q5_urb:per_sa_pw.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in Public Works programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_gini_rur:per_sa_pw_gini_rur} - Gini inequality index reduction (%) -  Public Works -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Public Works programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_gini_tot:per_sa_pw_gini_tot} - Gini inequality index reduction (%) -  Public Works}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Public Works programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_gini_urb:per_sa_pw_gini_urb} - Gini inequality index reduction (%) -  Public Works -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to Public Works programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p0_ep_tot:per_sa_pw_p0_ep_tot} - Poverty Headcount reduction (%) -  Public Works -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Public Works programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p0_rur:per_sa_pw_p0_rur} - Poverty Headcount reduction (%) -  Public Works -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Public Works programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p0_tot:per_sa_pw_p0_tot} - Poverty Headcount reduction (%) -  Public Works -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Public Works programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p0_urb:per_sa_pw_p0_urb} - Poverty Headcount reduction (%) -  Public Works - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to Public Works programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p1_ep_tot:per_sa_pw_p1_ep_tot} - Poverty Gap reduction (%) -  Public Works -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Public Works programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p1_rur:per_sa_pw_p1_rur} - Poverty Gap reduction (%) -  Public Works -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Public Works programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p1_tot:per_sa_pw_p1_tot} - Poverty Gap reduction (%) -  Public Works -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Public Works programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_pw_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_pw_p1_urb:per_sa_pw_p1_urb} - Poverty Gap reduction (%) -  Public Works - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to Public Works programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_ep_preT_tot:per_sa_sf.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_ep_tot:per_sa_sf.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_pop_rur:per_sa_sf.adq_pop_rur} - Adequacy of benefits (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_pop_tot:per_sa_sf.adq_pop_tot} - Adequacy of benefits (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_pop_urb:per_sa_sf.adq_pop_urb} - Adequacy of benefits (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q1_preT_tot:per_sa_sf.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q1_rur:per_sa_sf.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q1_tot:per_sa_sf.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q1_urb:per_sa_sf.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q2_preT_tot:per_sa_sf.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q2_rur:per_sa_sf.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q2_tot:per_sa_sf.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q2_urb:per_sa_sf.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q3_preT_tot:per_sa_sf.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q3_rur:per_sa_sf.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q3_tot:per_sa_sf.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q3_urb:per_sa_sf.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q4_preT_tot:per_sa_sf.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q4_rur:per_sa_sf.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q4_tot:per_sa_sf.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q4_urb:per_sa_sf.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q5_preT_tot:per_sa_sf.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q5_rur:per_sa_sf.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q5_tot:per_sa_sf.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.adq_q5_urb:per_sa_sf.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_ep_preT_tot:per_sa_sf.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_ep_tot:per_sa_sf.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_pop_rur:per_sa_sf.avt_pop_rur} - Average per capita transfer - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_pop_tot:per_sa_sf.avt_pop_tot} - Average per capita transfer - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_pop_urb:per_sa_sf.avt_pop_urb} - Average per capita transfer - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q1_preT_tot:per_sa_sf.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q1_rur:per_sa_sf.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q1_tot:per_sa_sf.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q1_urb:per_sa_sf.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q2_preT_tot:per_sa_sf.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q2_rur:per_sa_sf.avt_q2_rur} - Average per capita transfer held by 2nd quintile - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q2_tot:per_sa_sf.avt_q2_tot} - Average per capita transfer held by 2nd quintile - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q2_urb:per_sa_sf.avt_q2_urb} - Average per capita transfer held by 2nd quintile - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q3_preT_tot:per_sa_sf.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q3_rur:per_sa_sf.avt_q3_rur} - Average per capita transfer held by 3rd quintile - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q3_tot:per_sa_sf.avt_q3_tot} - Average per capita transfer held by 3rd quintile - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q3_urb:per_sa_sf.avt_q3_urb} - Average per capita transfer held by 3rd quintile - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q4_preT_tot:per_sa_sf.avt_q4_preT_tot} - Average per capita transfer held by 4th quintile - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q4_rur:per_sa_sf.avt_q4_rur} - Average per capita transfer held by 4th quintile - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q4_tot:per_sa_sf.avt_q4_tot} - Average per capita transfer held by 4th quintile - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q4_urb:per_sa_sf.avt_q4_urb} - Average per capita transfer held by 4th quintile - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q5_preT_tot:per_sa_sf.avt_q5_preT_tot} - Average per capita transfer held by 5th quintile (richest) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q5_rur:per_sa_sf.avt_q5_rur} - Average per capita transfer held by 5th quintile (richest) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q5_tot:per_sa_sf.avt_q5_tot} - Average per capita transfer held by 5th quintile (richest) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.avt_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.avt_q5_urb:per_sa_sf.avt_q5_urb} - Average per capita transfer held by 5th quintile (richest) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  School Feeding programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_ep_preT_tot:per_sa_sf.ben_ep_preT_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_ep_tot:per_sa_sf.ben_ep_tot} - Benefits incidence in extreme poor (&lt;$2.15 a day) (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the extreme poor (those below $125 a day)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q1_preT_tot:per_sa_sf.ben_q1_preT_tot} - Benefits incidence in 1st quintile (poorest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q1_rur:per_sa_sf.ben_q1_rur} - Benefits incidence in 1st quintile (poorest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q1_tot:per_sa_sf.ben_q1_tot} - Benefits incidence in 1st quintile (poorest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q1_urb:per_sa_sf.ben_q1_urb} - Benefits incidence in 1st quintile (poorest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the 1st quintile (poorest)  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q2_preT_tot:per_sa_sf.ben_q2_preT_tot} - Benefits incidence in 2nd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q2_rur:per_sa_sf.ben_q2_rur} - Benefits incidence in 2nd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q2_tot:per_sa_sf.ben_q2_tot} - Benefits incidence in 2nd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q2_urb:per_sa_sf.ben_q2_urb} - Benefits incidence in 2nd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the second quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q3_preT_tot:per_sa_sf.ben_q3_preT_tot} - Benefits incidence in 3rd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q3_rur:per_sa_sf.ben_q3_rur} - Benefits incidence in 3rd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q3_tot:per_sa_sf.ben_q3_tot} - Benefits incidence in 3rd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q3_urb:per_sa_sf.ben_q3_urb} - Benefits incidence in 3rd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the third quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q4_preT_tot:per_sa_sf.ben_q4_preT_tot} - Benefits incidence in 4th quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q4_rur:per_sa_sf.ben_q4_rur} - Benefits incidence in 4th quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q4_tot:per_sa_sf.ben_q4_tot} - Benefits incidence in 4th quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q4_urb:per_sa_sf.ben_q4_urb} - Benefits incidence in 4th quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the fourth quintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q5_preT_tot:per_sa_sf.ben_q5_preT_tot} - Benefits incidence in 5th quintile (richest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q5_rur:per_sa_sf.ben_q5_rur} - Benefits incidence in 5th quintile (richest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q5_tot:per_sa_sf.ben_q5_tot} - Benefits incidence in 5th quintile (richest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.ben_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.ben_q5_urb:per_sa_sf.ben_q5_urb} - Benefits incidence in 5th quintile (richest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of benefits going to the richestquintile  relative to the total benefits going to the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_ep_preT_tot:per_sa_sf.bry_ep_preT_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_ep_tot:per_sa_sf.bry_ep_tot} - Beneficiary incidence in extreme poor (&lt;$2.15 a day) (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q1_preT_tot:per_sa_sf.bry_q1_preT_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q1_rur:per_sa_sf.bry_q1_rur} - Beneficiary incidence in 1st quintile (poorest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q1_tot:per_sa_sf.bry_q1_tot} - Beneficiary incidence in 1st quintile (poorest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q1_urb:per_sa_sf.bry_q1_urb} - Beneficiary incidence in 1st quintile (poorest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q2_preT_tot:per_sa_sf.bry_q2_preT_tot} - Beneficiary incidence in 2nd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q2_rur:per_sa_sf.bry_q2_rur} - Beneficiary incidence in 2nd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q2_tot:per_sa_sf.bry_q2_tot} - Beneficiary incidence in 2nd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q2_urb:per_sa_sf.bry_q2_urb} - Beneficiary incidence in 2nd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q3_preT_tot:per_sa_sf.bry_q3_preT_tot} - Beneficiary incidence in 3rd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q3_rur:per_sa_sf.bry_q3_rur} - Beneficiary incidence in 3rd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q3_tot:per_sa_sf.bry_q3_tot} - Beneficiary incidence in 3rd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q3_urb:per_sa_sf.bry_q3_urb} - Beneficiary incidence in 3rd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q4_preT_tot:per_sa_sf.bry_q4_preT_tot} - Beneficiary incidence in 4th quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q4_rur:per_sa_sf.bry_q4_rur} - Beneficiary incidence in 4th quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q4_tot:per_sa_sf.bry_q4_tot} - Beneficiary incidence in 4th quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q4_urb:per_sa_sf.bry_q4_urb} - Beneficiary incidence in 4th quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q5_preT_tot:per_sa_sf.bry_q5_preT_tot} - Beneficiary incidence in 5th quintile (richest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q5_rur:per_sa_sf.bry_q5_rur} - Beneficiary incidence in 5th quintile (richest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q5_tot:per_sa_sf.bry_q5_tot} - Beneficiary incidence in 5th quintile (richest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.bry_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.bry_q5_urb:per_sa_sf.bry_q5_urb} - Beneficiary incidence in 5th quintile (richest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of program beneficiaries in a quintile relative to the total number of beneficiaries in the population{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cba_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cba_ep_tot:per_sa_sf.cba_ep_tot} - Benefit-cost ratio -  School-feeding -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in School Feeding programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cba_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cba_q1_rur:per_sa_sf.cba_q1_rur} - Benefit-cost ratio -  School-feeding -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in School Feeding programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cba_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cba_q1_tot:per_sa_sf.cba_q1_tot} - Benefit-cost ratio -  School-feeding -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in School Feeding programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cba_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cba_q1_urb:per_sa_sf.cba_q1_urb} - Benefit-cost ratio -  School-feeding - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction obtained for each $1 spent in School Feeding programs (%){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_ep_preT_tot:per_sa_sf.cov_ep_preT_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_ep_tot:per_sa_sf.cov_ep_tot} - Coverage in extreme poor (&lt;$2.15 a day) (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_pop_rur:per_sa_sf.cov_pop_rur} - Coverage (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_pop_tot:per_sa_sf.cov_pop_tot} - Coverage (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_pop_urb:per_sa_sf.cov_pop_urb} - Coverage (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q1_preT_tot:per_sa_sf.cov_q1_preT_tot} - Coverage in 1st quintile (poorest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q1_rur:per_sa_sf.cov_q1_rur} - Coverage in 1st quintile (poorest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q1_tot:per_sa_sf.cov_q1_tot} - Coverage in 1st quintile (poorest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q1_urb:per_sa_sf.cov_q1_urb} - Coverage in 1st quintile (poorest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q2_preT_tot:per_sa_sf.cov_q2_preT_tot} - Coverage in 2nd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q2_rur:per_sa_sf.cov_q2_rur} - Coverage in 2nd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q2_tot:per_sa_sf.cov_q2_tot} - Coverage in 2nd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q2_urb:per_sa_sf.cov_q2_urb} - Coverage in 2nd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q3_preT_tot:per_sa_sf.cov_q3_preT_tot} - Coverage in 3rd quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q3_rur:per_sa_sf.cov_q3_rur} - Coverage in 3rd quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q3_tot:per_sa_sf.cov_q3_tot} - Coverage in 3rd quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q3_urb:per_sa_sf.cov_q3_urb} - Coverage in 3rd quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q4_preT_tot:per_sa_sf.cov_q4_preT_tot} - Coverage in 4th quintile (%) - School Feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q4_rur:per_sa_sf.cov_q4_rur} - Coverage in 4th quintile (%) - School Feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q4_tot:per_sa_sf.cov_q4_tot} - Coverage in 4th quintile (%) - School Feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q4_urb:per_sa_sf.cov_q4_urb} - Coverage in 4th quintile (%) - School Feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q5_preT_tot:per_sa_sf.cov_q5_preT_tot} - Coverage in 5th quintile (richest) (%) - School feeding (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q5_rur:per_sa_sf.cov_q5_rur} - Coverage in 5th quintile (richest) (%) - School feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q5_tot:per_sa_sf.cov_q5_tot} - Coverage in 5th quintile (richest) (%) - School feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf.cov_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf.cov_q5_urb:per_sa_sf.cov_q5_urb} - Coverage in 5th quintile (richest) (%) - School feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Percentage of population participating in School Feeding programs (includes direct and indirect beneficiaries){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_gini_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_gini_rur:per_sa_sf_gini_rur} - Gini inequality index reduction (%) -  School-feeding -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to School Feeding programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_gini_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_gini_tot:per_sa_sf_gini_tot} - Gini inequality index reduction (%) -  School-feeding}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to School Feeding programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_gini_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_gini_urb:per_sa_sf_gini_urb} - Gini inequality index reduction (%) -  School-feeding -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Gini inequality index reduction due to School Feeding programs as % of pre-transfer Gini index{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p0_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p0_ep_tot:per_sa_sf_p0_ep_tot} - Poverty Headcount reduction (%) -  School-feeding -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to School Feeding programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p0_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p0_rur:per_sa_sf_p0_rur} - Poverty Headcount reduction (%) -  School-feeding -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to School Feeding programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p0_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p0_tot:per_sa_sf_p0_tot} - Poverty Headcount reduction (%) -  School-feeding -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to School Feeding programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p0_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p0_urb:per_sa_sf_p0_urb} - Poverty Headcount reduction (%) -  School-feeding - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty headcount reduction due to School Feeding programs as % of pre-transfer poverty headcount{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p1_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p1_ep_tot:per_sa_sf_p1_ep_tot} - Poverty Gap reduction (%) -  School-feeding -extreme poor (&lt;$2.15 a day)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to School Feeding programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p1_rur:per_sa_sf_p1_rur} - Poverty Gap reduction (%) -  School-feeding -1st quintile (poorest) -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to School Feeding programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p1_tot:per_sa_sf_p1_tot} - Poverty Gap reduction (%) -  School-feeding -1st quintile (poorest)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to School Feeding programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sf_p1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sf_p1_urb:per_sa_sf_p1_urb} - Poverty Gap reduction (%) -  School-feeding - 1st quintile (poorest) -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Poverty gap reduction due to School Feeding programs as % of pre-transfer poverty gap{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_ep_preT_tot:per_sa_sp.adq_ep_preT_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Social Pensions  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_ep_tot:per_sa_sp.adq_ep_tot} - Adequacy of benefits in extreme poor (&lt;$2.15 a day) (%) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_pop_rur:per_sa_sp.adq_pop_rur} - Adequacy of benefits (%) - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_pop_tot:per_sa_sp.adq_pop_tot} - Adequacy of benefits (%) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_pop_urb:per_sa_sp.adq_pop_urb} - Adequacy of benefits (%) - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q1_preT_tot:per_sa_sp.adq_q1_preT_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q1_rur:per_sa_sp.adq_q1_rur} - Adequacy of benefits in 1st quintile (poorest) (%) - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q1_tot:per_sa_sp.adq_q1_tot} - Adequacy of benefits in 1st quintile (poorest) (%) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q1_urb:per_sa_sp.adq_q1_urb} - Adequacy of benefits in 1st quintile (poorest) (%) - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q2_preT_tot:per_sa_sp.adq_q2_preT_tot} - Adequacy of benefits in 2nd quintile (%) - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q2_rur:per_sa_sp.adq_q2_rur} - Adequacy of benefits in 2nd quintile (%) - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q2_tot:per_sa_sp.adq_q2_tot} - Adequacy of benefits in 2nd quintile (%) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q2_urb:per_sa_sp.adq_q2_urb} - Adequacy of benefits in 2nd quintile (%) - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q3_preT_tot:per_sa_sp.adq_q3_preT_tot} - Adequacy of benefits in 3rd quintile (%) - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q3_rur:per_sa_sp.adq_q3_rur} - Adequacy of benefits in 3rd quintile (%) - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q3_tot:per_sa_sp.adq_q3_tot} - Adequacy of benefits in 3rd quintile (%) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q3_urb:per_sa_sp.adq_q3_urb} - Adequacy of benefits in 3rd quintile (%) - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q4_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q4_preT_tot:per_sa_sp.adq_q4_preT_tot} - Adequacy of benefits in 4th quintile (%) - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q4_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q4_rur:per_sa_sp.adq_q4_rur} - Adequacy of benefits in 4th quintile (%) - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q4_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q4_tot:per_sa_sp.adq_q4_tot} - Adequacy of benefits in 4th quintile (%) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q4_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q4_urb:per_sa_sp.adq_q4_urb} - Adequacy of benefits in 4th quintile (%) - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q5_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q5_preT_tot:per_sa_sp.adq_q5_preT_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q5_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q5_rur:per_sa_sp.adq_q5_rur} - Adequacy of benefits in 5th quintile (richest) (%) - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q5_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q5_tot:per_sa_sp.adq_q5_tot} - Adequacy of benefits in 5th quintile (richest) (%) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.adq_q5_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.adq_q5_urb:per_sa_sp.adq_q5_urb} - Adequacy of benefits in 5th quintile (richest) (%) - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Total transfer amount received by all beneficiaries in a population group as a share of the total welfare of beneficiaries in that group{p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_ep_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_ep_preT_tot:per_sa_sp.avt_ep_preT_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Social Pensions  (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_ep_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_ep_tot:per_sa_sp.avt_ep_tot} - Average per capita transfer held by extreme poor (&lt;$2.15 a day) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_pop_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_pop_rur:per_sa_sp.avt_pop_rur} - Average per capita transfer - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_pop_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_pop_tot:per_sa_sp.avt_pop_tot} - Average per capita transfer - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_pop_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_pop_urb:per_sa_sp.avt_pop_urb} - Average per capita transfer - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q1_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q1_preT_tot:per_sa_sp.avt_q1_preT_tot} - Average per capita transfer held by 1st quintile (poorest) - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q1_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q1_rur:per_sa_sp.avt_q1_rur} - Average per capita transfer held by 1st quintile (poorest) - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q1_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q1_tot:per_sa_sp.avt_q1_tot} - Average per capita transfer held by 1st quintile (poorest) - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q1_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q1_urb:per_sa_sp.avt_q1_urb} - Average per capita transfer held by 1st quintile (poorest) - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q2_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q2_preT_tot:per_sa_sp.avt_q2_preT_tot} - Average per capita transfer held by 2nd quintile - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q2_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q2_rur:per_sa_sp.avt_q2_rur} - Average per capita transfer held by 2nd quintile - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q2_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q2_tot:per_sa_sp.avt_q2_tot} - Average per capita transfer held by 2nd quintile - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q2_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q2_urb:per_sa_sp.avt_q2_urb} - Average per capita transfer held by 2nd quintile - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q3_preT_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q3_preT_tot:per_sa_sp.avt_q3_preT_tot} - Average per capita transfer held by 3rd quintile - Social Pensions (preT)}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q3_rur}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q3_rur:per_sa_sp.avt_q3_rur} - Average per capita transfer held by 3rd quintile - Social Pensions -rural}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q3_tot}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q3_tot:per_sa_sp.avt_q3_tot} - Average per capita transfer held by 3rd quintile - Social Pensions}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}


{synoptline}
{marker topicid_per_sa_sp.avt_q3_urb}
{synopt:{bf:{help wbopendata_topicid##per_sa_sp.avt_q3_urb:per_sa_sp.avt_q3_urb} - Average per capita transfer held by 3rd quintile - Social Pensions -urban}}

{synopt:{opt Source}}29 The Atlas of Social Protection: Indicators of Resilience and Equity{p_end}

{synopt:{opt Topics}}10 Social Protection and Labor{p_end}

{synopt:{opt Source Notes}}Average transfer amount of  Social Pensions programs among program beneficiaries (per capita, daily ){p_end}

{synopt:{opt Source Organization}}ASPIRE{p_end}



{right:(as of 04jan2026)}
